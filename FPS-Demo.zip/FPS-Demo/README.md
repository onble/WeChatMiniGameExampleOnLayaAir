# FPS-Demo
本Demo使用LayaAir3.0.6开发，请使用Laya引擎打开项目。
项目文件夹中附带打包为Android的APK文件，提供安卓端快速预览。
