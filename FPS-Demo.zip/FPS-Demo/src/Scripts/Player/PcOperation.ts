import { OperationBase } from "./OperationBase";

const { regClass, property } = Laya;

@regClass()
export class PcOpenration extends OperationBase {
    private isMouseClicked: boolean = false;
    onAwake(): void {
        super.onAwake();
        // Laya.stage.on(Laya.Event.RIGHT_MOUSE_UP, this, () => {
        //     this.manager.RightMouseUp();
        // });

        Laya.stage.on(Laya.Event.RIGHT_MOUSE_UP, this, () => {
            this.manager.RightMouseUp();
        });

        // 监听鼠标和触摸点击事件
        Laya.stage.on(Laya.Event.MOUSE_DOWN, this, this.onMouseDown);
        Laya.stage.on(Laya.Event.MOUSE_UP, this, this.onMouseUp);
    }

    onUpdate(): void {
        this.manager.isMoving = false;
        this.manager.moveForward = false;
        if (Laya.InputManager.hasKeyDown(Laya.Keyboard.W)) {
            this.manager.moveForward = true;
            this.manager.isMoving = true;
            this.playerTrs.getForward(this.manager.moveAngle);
            this.manager.moveAngle.x = -this.manager.moveAngle.x;
            this.manager.moveAngle.z = -this.manager.moveAngle.z;
        }
        if (Laya.InputManager.hasKeyDown(Laya.Keyboard.S)) {
            this.manager.isMoving = true;
            this.playerTrs.getForward(this.manager.moveAngle);
        }
        if (Laya.InputManager.hasKeyDown(Laya.Keyboard.D)) {
            this.manager.isMoving = true;
            this.playerTrs.getRight(this.manager.moveAngle);
            this.manager.moveAngle.x = -this.manager.moveAngle.x;
            this.manager.moveAngle.z = -this.manager.moveAngle.z;
        }
        if (Laya.InputManager.hasKeyDown(Laya.Keyboard.A)) {
            this.manager.isMoving = true;
            this.playerTrs.getRight(this.manager.moveAngle);
        }
        // console.log(this.manager.moveAngle.x, this.manager.moveAngle.z);

        this.manager.isRunning = Laya.InputManager.hasKeyDown(
            Laya.Keyboard.SHIFT
        );
        this.manager.isJumping = Laya.InputManager.hasKeyDown(
            Laya.Keyboard.SPACE
        );

        this.manager.isShooting = Laya.InputManager.hasKeyDown(Laya.Keyboard.F);
        // 在update方法中检查鼠标点击状态
        // if (this.isMouseClicked) {
        //     console.log("鼠标被点击了！");
        //     this.isMouseClicked = false; // 重置点击状态
        //     this.manager.isShooting = true;
        // }

        // console.log("mytest Laya.Event.MOUSE_DOWN", Laya.Event.MOUSE_DOWN);
        this.manager.isReloading = Laya.InputManager.hasKeyDown(
            Laya.Keyboard.R
        );
    }
}
