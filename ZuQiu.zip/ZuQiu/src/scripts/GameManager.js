import ScorePanel from "./ScorePanel";

/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2021-05-21 12:25
*/
export default class GameManager extends Laya.Script {

    constructor() {
        super();
        /** @prop {name:scorePanel, tips:"提示文本", type:Node, default:null}*/
        this.scorePanel=null;
        /** @prop {name:gameOverPanel, tips:"提示文本", type:Node, default:null}*/
        this.gameOverPanel=null;
        /** @prop {name:txt_CountDown, tips:"提示文本", type:Node, default:null}*/
        this.txt_CountDown=null;
        /** @prop {name:btn_Pause, tips:"提示文本", type:Node, default:null}*/
        this.btn_Pause=null;
        /** @prop {name:pausePanel, tips:"提示文本", type:Node, default:null}*/
        this.pausePanel=null;

        this.scorePanelScript=null;

        this.MyScore=0;
        this.AIScore=0;

        this.timer=0;
        this.time=3;
        this.isStartGame=false;

        this.countDownTime=90;
        this.gameOver=false;
    }
    onAwake(){
        Laya.SoundManager.playMusic("sound/Crowd/crowd-01.mp3",0)
        //游戏结束界面两个按钮的点击事件的监听
        this.gameOverPanel.getChildByName("btn_Menu").on(Laya.Event.CLICK,this,function(){
            //场景的跳转
            Laya.Scene.open("Menu.json")
        })
        this.gameOverPanel.getChildByName("btn_Again").on(Laya.Event.CLICK,this,function(){
            //重新加载当前场景
            Laya.Scene.open("Main.json")
        })

        this.btn_Pause.on(Laya.Event.CLICK,this,function(){
            Laya.SoundManager.playSound("sound/MenuTap.mp3",1)
            this.pausePanel.visible=true;
            Laya.timer.scale=0
        })
        //暂停界面三个按钮的点击事件监听
        this.pausePanel.getChildByName("btn_Menu").on(Laya.Event.CLICK,this,function(){
            Laya.SoundManager.playSound("sound/MenuTap.mp3",1)
            Laya.Scene.open("Menu.json")
            Laya.timer.scale=1
        })
        this.pausePanel.getChildByName("btn_Resume").on(Laya.Event.CLICK,this,function(){
            Laya.SoundManager.playSound("sound/MenuTap.mp3",1)
            this.pausePanel.visible=false;
            Laya.timer.scale=1
        })
        this.pausePanel.getChildByName("btn_Restart").on(Laya.Event.CLICK,this,function(){
            Laya.SoundManager.playSound("sound/MenuTap.mp3",1)
            Laya.Scene.open("Main.json")
            Laya.timer.scale=1
        })

        this.scorePanelScript=this.scorePanel.getComponent(ScorePanel);
    }
    onUpdate(){
        if(this.isStartGame==false){
            this.timer+=Laya.timer.delta/1000;
            if(this.timer>=1){
                this.timer=0;
                this.time--;
                if(this.time<=0){
                    this.isStartGame=true;
                    this.txt_CountDown.visible=false;
                    this.StartGame()
                    return;
                }
                this.txt_CountDown.text=this.time
            }
        }
        else if(this.gameOver==false){
            this.timer+=Laya.timer.delta/1000;
            if(this.timer>=1){
                this.timer=0;
                this.countDownTime--;
                this.scorePanelScript.UpdateTime(this.countDownTime)
                if(this.countDownTime<=0){
                    //游戏结束
                    this.gameOver=true;
                    this.GameOver()
                }
            }
        }
    }
    GameOver(){
        this.gameOverPanel.visible=true;
        Laya.stage.event("GameOver")
        var txt_Result=this.gameOverPanel.getChildByName("txt_Result")
        if(this.MyScore>this.AIScore){
            txt_Result.text="胜利"
        }
        else if(this.MyScore<this.AIScore){
            txt_Result.text="失败"
        }
        else{
            txt_Result.text="平局"
        }
    }
    StartGame(){
        this.btn_Pause.visible=true;
        Laya.SoundManager.playSound("sound/startWistle.mp3",1,
        new Laya.Handler(this,function(){
            Laya.stage.event("StartGame")
        }));
    }
    AddMyScore(){
        this.MyScore++;
        this.scorePanelScript.UpdateMyScore(this.MyScore)
    }
    AddAIScore(){
        this.AIScore++;
        this.scorePanelScript.UpdateAIScore(this.AIScore)
    }
}