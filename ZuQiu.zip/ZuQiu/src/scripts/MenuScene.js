/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2021-05-21 17:57
*/
export default class MenuScene extends Laya.Script {

    constructor() {
        super();
        /** @prop {name:btn_Start, tips:"提示文本", type:Node, default:null}*/
        this.btn_Start=null;
        /** @prop {name:btn_Left, tips:"提示文本", type:Node, default:null}*/
        this.btn_Left=null;
        /** @prop {name:btn_Right, tips:"提示文本", type:Node, default:null}*/
        this.btn_Right=null;
        /** @prop {name:img_Head, tips:"提示文本", type:Node, default:null}*/
        this.img_Head=null;

        this.headIndex=1;
    }

    onAwake() {
        Laya.stage.pivot(960,0)
        Laya.stage.x=Laya.stage.width/2
        //Laya.stage.y=Laya.stage.height/2

        //先获取一下本地存放的HeadIndex的值
        if(Laya.LocalStorage.getItem("HeadIndex")!=null){
            this.headIndex=Laya.LocalStorage.getItem("HeadIndex")
            var skinUrl="Textures/Players/Player-Head-0"+this.headIndex+"-n.png"
            this.img_Head.skin=skinUrl
        }

        this.btn_Start.on(Laya.Event.CLICK,this,function(){
            Laya.SoundManager.playSound("sound/MenuTap.mp3",1)
            Laya.LocalStorage.setItem("HeadIndex",this.headIndex)
            Laya.Scene.open("Main.json")
        })
        this.btn_Left.on(Laya.Event.CLICK,this,function(){
            Laya.SoundManager.playSound("sound/MenuTap.mp3",1)
            this.headIndex--;
            //1-4
            if(this.headIndex<1){
                this.headIndex=4
            }
            var skinUrl="Textures/Players/Player-Head-0"+this.headIndex+"-n.png"
            this.img_Head.skin=skinUrl
        })
        this.btn_Right.on(Laya.Event.CLICK,this,function(){
            Laya.SoundManager.playSound("sound/MenuTap.mp3",1)
            this.headIndex++;
            if(this.headIndex>4){
                this.headIndex=1
            }
            var skinUrl="Textures/Players/Player-Head-0"+this.headIndex+"-n.png"
            this.img_Head.skin=skinUrl
        })
    }
}