import GameManager from "./GameManager";

/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2021-05-20 18:22
*/
export default class AIPlayerController extends Laya.Script {

    constructor() {
        super();
        /** @prop {name:ball, tips:"提示文本", type:Node, default:null}*/
        this.ball=null;
        /** @prop {name:shoe, tips:"提示文本", type:Node, default:null}*/
        this.shoe=null;

        this.img_Head=null;
        this.headIndex=1;

        this.rig=null;
        this.gameManager=null;

        this.minX=1020
        this.maxX=1660;
        //AI触发跳跃的高度
        this.minJumpDistance=230;
        this.canJump=true;
        this.jumpSpeed=-12;

        //上一帧X的位置
        this.lastX=0;

        this.offsetX=0;
    }
    //重置AI玩家位置
    reset(){
        this.gameManager.AddMyScore()
        this.owner.x=1260
        this.owner.y=770
        this.owner.getComponent(Laya.RigidBody).setVelocity({x:0,y:0})
    }

    onAwake() {
        this.img_Head=this.owner.getChildByName("head")
        this.headIndex=Number.parseInt(this.getRandom(1,5))
        var skinUrl="Textures/Players/Player-Head-0"+this.headIndex+"-n.png"
        this.img_Head.texture=skinUrl;

        this.gameManager=this.owner.parent.getComponent(GameManager)
        this.rig=this.owner.getComponent(Laya.RigidBody);
        Laya.stage.on("ResetAIPlayer",this,this.reset)
    }
    onDestroy(){
        Laya.stage.off("ResetAIPlayer",this,this.reset)
    }
    onUpdate(){
        if(this.gameManager.gameOver){
            this.shoe.rotation=0;
            return;
        }
        if(this.owner.y>773){
            this.canJump=true
        }

        if(this.ball.x>this.minX&&this.ball.x<this.maxX){
            //this.owner.x=this.ball.x+this.offsetX
            var targetX=this.ball.x+this.offsetX
            this.owner.x=Laya.MathUtil.lerp(this.owner.x,targetX,
                Laya.timer.delta/1000*10)
           
            //鞋的旋转
            if(this.owner.x>this.lastX){//向后
                this.shoe.rotation=23;
            }
            else{
                this.shoe.rotation=-23;
            }
            this.lastX=this.owner.x

            //判断球和AI之间的距离，跳跃
            var delX=this.owner.x-this.ball.x;
            var delY=this.owner.y-this.ball.y;
            var dis=Math.sqrt(delX*delX+delY*delY)
            if(dis<this.minJumpDistance&&this.canJump){
                this.canJump=false;
                var x=this.rig.linearVelocity.x;
                var y=this.jumpSpeed-this.getRandom(1,5)
                this.rig.setVelocity({x:x,y:y})
            }
        }
        else{
            this.shoe.rotation=0;
            this.offsetX=this.getRandom(20,40)
        }
    }
    getRandom(min,max){
        //1 5 =4
        var value=max-min;
        value=Math.random()*value//0 - 4
        return value+min;//1 -5
    }
    onTriggerEnter(other){
        if(other.owner.name=="ball"){
            Laya.timer.clearAll(this)
            var skinUrl="Textures/Players/Player-Head-0"+this.headIndex+"-c.png"
            this.img_Head.texture=skinUrl;
            Laya.timer.once(1000,this,function(){
                var skinUrl="Textures/Players/Player-Head-0"+this.headIndex+"-n.png"
                this.img_Head.texture=skinUrl;
            })
        }
    }
}