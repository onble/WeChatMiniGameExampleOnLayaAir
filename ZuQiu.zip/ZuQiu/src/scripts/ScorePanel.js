/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2021-05-21 12:20
*/
export default class ScorePanel extends Laya.Script {

    constructor() {
        super();
        /** @prop {name:txt_TimeCount, tips:"提示文本", type:Node, default:null}*/
        this.txt_TimeCount=null;
        /** @prop {name:txt_MyScore, tips:"提示文本", type:Node, default:null}*/
        this.txt_MyScore=null;
        /** @prop {name:txt_AIScore, tips:"提示文本", type:Node, default:null}*/
        this.txt_AIScore=null;
    }
    UpdateMyScore(score){
        this.txt_MyScore.text=score;
    }
    UpdateAIScore(score){
        this.txt_AIScore.text=score;
    }
    UpdateTime(time){
        this.txt_TimeCount.text=time;
    }
}