import GameManager from "./GameManager";

/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2021-05-21 11:05
*/
export default class Ball extends Laya.Script {

    constructor() {
        super();
        this.rig=null;
        this.gameManager=null;
    }
    onAwake(){
        this.gameManager=this.owner.parent.getComponent(GameManager)
        this.rig=this.owner.getComponent(Laya.RigidBody)
        Laya.stage.on("StartGame",this,this.StartGame)
        Laya.stage.on("GameOver",this,function(){
            Laya.SoundManager.setSoundVolume(0,"sound/Goal/goal-received.wav")
            Laya.SoundManager.setSoundVolume(0,"sound/startWistle.mp3")
            Laya.SoundManager.setSoundVolume(0,"sound/Goal/goal-landed-01.mp3")
        })
    }
    onDestroy(){
        Laya.stage.off("StartGame",this,this.StartGame)
        Laya.stage.off("GameOver",this)
    }
    StartGame(){
        if(this.gameManager.isStartGame)
        this.rig.type="dynamic"
    }
    reset(x){
        this.owner.x=x;
        this.owner.y=260
        this.rig.setVelocity({x:0,y:0})
        this.rig.angularVelocity=0
        this.rig.type="kinematic"
    }
    onTriggerEnter(other){
        if(this.gameManager.gameOver)return;
        
        if(other.owner.name=="down"){
            Laya.SoundManager.playSound("sound/Ball-Hit-Ground.wav",1)
            if(this.owner.x<960){
                //left 失分
                Laya.SoundManager.playSound("sound/Goal/goal-received.wav",1,
                new Laya.Handler(this,function(){
                    if(this.gameManager.gameOver)return;
                    Laya.SoundManager.playSound("sound/startWistle.mp3",1,
                        new Laya.Handler(this,function(){
                            Laya.stage.event("StartGame")
                        }));
                }))
                this.reset(752)
                Laya.stage.event("ResetMyPlayer")
            }else{
                //right 得分
                Laya.SoundManager.playSound("sound/Goal/goal-landed-01.mp3",1,
                new Laya.Handler(this,function(){
                    if(this.gameManager.gameOver)return;
                    Laya.SoundManager.playSound("sound/startWistle.mp3",1,
                        new Laya.Handler(this,function(){
                            Laya.stage.event("StartGame")
                        }));
                }))
                this.reset(1170)
                Laya.stage.event("ResetAIPlayer")
            }
        }
        if(other.owner.name=="myPlayer"){
            Laya.SoundManager.playSound("sound/BallHit-01.mp3",1)
        }
        if(other.owner.name=="aiPlayer"){
            Laya.SoundManager.playSound("sound/BallHit-02.mp3",1)
        }
        if(other.owner.name=="pole"){
            Laya.SoundManager.playSound("sound/ballHitsMiddlePole.mp3",1)
        }
    }
}