import GameManager from "./GameManager";

/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2021-05-20 16:00
*/
export default class MyPlayerController extends Laya.Script {

    constructor() {
        super();
        /** @prop {name:shoe, tips:"提示文本", type:Node, default:null}*/
        this.shoe=null;
        /** @prop {name:btn_Left, tips:"提示文本", type:Node, default:null}*/
        this.btn_Left=null;
        /** @prop {name:btn_Right, tips:"提示文本", type:Node, default:null}*/
        this.btn_Right=null;
        /** @prop {name:btn_Jump, tips:"提示文本", type:Node, default:null}*/
        this.btn_Jump=null;

        this.img_Head=null;
        this.rig=null;
        //是否可以跳跃
        this.canJump=true;
        this.gameManager=null;

        this.canLeft=false;
        this.canRight=false;
    }
    reset(){
        this.gameManager.AddAIScore()
        this.owner.x=660
        this.owner.y=770
        this.rig.setVelocity({x:0,y:0})
    }
    onAwake() {
        this.img_Head=this.owner.getChildByName("head")
        var index=Laya.LocalStorage.getItem("HeadIndex")
        var skinUrl="Textures/Players/Player-Head-0"+index+"-n.png"
        this.img_Head.texture=skinUrl;

        this.gameManager=this.owner.parent.getComponent(GameManager);
        this.rig=this.owner.getComponent(Laya.RigidBody)
        Laya.stage.on("ResetMyPlayer",this,this.reset)

        this.btn_Left.on(Laya.Event.MOUSE_DOWN,this,function(){
            this.canLeft=true;
        })
        this.btn_Left.on(Laya.Event.MOUSE_UP,this,function(){
            this.canLeft=false;
        })
        this.btn_Left.on(Laya.Event.MOUSE_OUT,this,function(){
            this.canLeft=false;
        })
        this.btn_Right.on(Laya.Event.MOUSE_DOWN,this,function(){
            this.canRight=true;
        })
        this.btn_Right.on(Laya.Event.MOUSE_UP,this,function(){
            this.canRight=false;
        })
        this.btn_Right.on(Laya.Event.MOUSE_OUT,this,function(){
            this.canRight=false;
        })
        
        this.btn_Jump.on(Laya.Event.CLICK,this,this.Jump)
    }
    onDestroy(){
        Laya.stage.off("ResetMyPlayer",this,this.reset)
    }
    onUpdate(){

        if(this.canLeft){
            this.MoveLeft()
        }
        if(this.canRight){
            this.MoveRight()
        }
        this.rotationShoe();

        if(Laya.KeyBoardManager.hasKeyDown(Laya.Keyboard.A)){
            this.MoveLeft()
        }
        if(Laya.KeyBoardManager.hasKeyDown(Laya.Keyboard.D)){
            this.MoveRight()
        }

        if(this.owner.y>773){
            this.canJump=true
        }
    }
    onKeyDown(e){
        //Jump
        if(e.nativeEvent.key==" "){
            this.Jump()
        }
    }
    MoveLeft(){
        if(this.gameManager.gameOver)return;
        var y=this.rig.linearVelocity.y
        this.rig.setVelocity({x:-10,y:y})
    }
    MoveRight(){
        if(this.gameManager.gameOver)return;
        var y=this.rig.linearVelocity.y
        this.rig.setVelocity({x:10,y:y})
    }
    Jump(){
        if(this.canJump==false)return;
        if(this.gameManager.gameOver)return;
        this.canJump=false
        var x=this.rig.linearVelocity.x
        this.rig.setVelocity({x:x,y:-13})
    }
    //鞋的旋转
    rotationShoe(){
        //向右
        if(this.rig.linearVelocity.x>0.1){
            this.shoe.rotation=23
        }
        //向左
        else if(this.rig.linearVelocity.x<-0.1){
            this.shoe.rotation=-23
        }
        else{
            this.shoe.rotation=0
        }
    }
    onTriggerEnter(other){
        if(other.owner.name=="ball"){
            Laya.timer.clearAll(this)
            var index=Laya.LocalStorage.getItem("HeadIndex")
            var skinUrl="Textures/Players/Player-Head-0"+index+"-c.png"
            this.img_Head.texture=skinUrl;
            Laya.timer.once(1000,this,function(){
                var skinUrl="Textures/Players/Player-Head-0"+index+"-n.png"
                this.img_Head.texture=skinUrl;
            })
        }
    }
}