/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-31 17:20
*/
export default class BgMusic extends Laya.Script {

    constructor() {
        super();
        this.soundChannel=null;
    }
    static Play(){
        this.soundChannel=Laya.SoundManager.playMusic("res/Sounds/gamePlayMusic.mp3",0);
        var isMute=Number(Laya.LocalStorage.getItem("Mute"))
        var volume=isMute==1?0:1;
        this.soundChannel.volume=volume;
        console.log(volume)
    }
    static SetVolume(volume){
        this.soundChannel.volume=volume;
    }
}