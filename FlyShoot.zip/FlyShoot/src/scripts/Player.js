import Data from "./Data";
import SpawnBullet from "./Bullet/SpawnBullet";
import EffectManager from "./EffectManager";
import BulletCtrl from "./Bullet/BulletCtrl";
import PropCtrl from "./PropCtrl";

/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-28 20:22
*/
export default class Player extends Laya.Script {

    constructor() {
        super();

        this.upBtnDown=false;
        this.bulletType="P_B_1";
        this.hp=1;
    }

    onAwake() {
        this.loadAnimation();
        SpawnBullet.instance.preLoad();
        this.Init();
    }
    loadAnimation(){
        var index=Data.getInstance().getChooseSKinIndex();
        index+=1;
        var aniPath="Animation/Player/"+index+".ani";
        this.owner.loadAnimation(aniPath);
    }
    Init(){
        Laya.stage.on("UpButtonDown",this,function(){
            this.upBtnDown=true;
            this.owner.autoAnimation="fly";
            this.owner.getChildByName("smoke").visible=true;
        });
        Laya.stage.on("UpButtonUp",this,function(){this.upBtnDown=false});
        Laya.stage.on("Shoot",this,this.Shoot);

        this.rig=this.owner.getComponent(Laya.RigidBody);
        this.spawnPoint=this.owner.getChildByName("spawnPoint");
    }
    onUpdate(){
        if(this.upBtnDown){
            this.rig.linearVelocity={x:0,y:-10}
        }
    }
    /**
     * 射击
     */
    Shoot(){
        Laya.SoundManager.playSound("res/Sounds/PlayerShoot.ogg",1);
        SpawnBullet.instance.spawn(this.bulletType,this.spawnPoint);
    }
    onTriggerEnter(other){
        if(other.label=="Ground"){
            this.owner.autoAnimation="walk";
            this.owner.getChildByName("smoke").visible=false;
        }
        //吃到金币
        if(other.label=="Coin"&&other.owner.visible){
            Laya.SoundManager.playSound("res/Sounds/HitCoin.ogg",1);
            other.owner.visible=false;
            var coinCount=Data.getInstance().addCoinCount();
            Laya.stage.event("AddCoin",coinCount);
            this.owner.parent.getChildByName("EffectCoin").getComponent(EffectManager).Show(this.owner.x,this.owner.y);
        }
        //碰到刺
        if(other.label=="Nail"){
            this.Demage(0.1);
        }
        //碰到敌人发射的子弹
        if(other.label=="EB"&&other.owner.visible){
            var demageValue=other.owner.getComponent(BulletCtrl).demageValue;
            this.Demage(demageValue);
            other.owner.visible=false;
        }
        if(other.label=="Enemy"&&other.owner.visible){
            other.owner.visible=false;
            if(other.owner.getComponent(PropCtrl)!=null){
                other.owner.x=2100;
            }
            this.Demage(0.1);
        }
        if(other.label=="Heal"&&other.owner.visible){
            other.owner.visible=false;
            other.owner.x=2100;
            this.hp+=0.3;
            this.hp=Number(this.hp.toFixed(1))
            if(this.hp>1){
                this.hp=1;
            }
            Laya.stage.event("Hp",this.hp);
        }
        if((other.label=="P_B_1"||other.label=="P_B_2")&&other.owner.visible){
            other.owner.x=2100;
            other.owner.visible=false;
            this.bulletType=other.label;
        }
    }
    /**
     * 受伤
     * @param {*} value 
     */
    Demage(value){
        Laya.SoundManager.playSound("res/Sounds/explosion03.ogg",1);
        this.hp-=value;
        this.hp=Number(this.hp.toFixed(1))
        Laya.stage.event("Hp",this.hp);
        
        if(this.hp<=0){
            //游戏结束
            //播放特效
            this.owner.parent.getChildByName("EffectOver").getComponent(EffectManager).Show(this.owner.x,this.owner.y);
            this.owner.removeSelf();
            Laya.stage.event("GameOver");
            Laya.timer.once(500,this,function(){Laya.timer.pause();});
            return;
        }
        this.owner.parent.getChildByName("EffectDemage").getComponent(EffectManager).Show(this.owner.x,this.owner.y);
    }
}