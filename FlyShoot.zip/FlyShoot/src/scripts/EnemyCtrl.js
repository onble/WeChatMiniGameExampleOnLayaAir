import BulletCtrl from "./Bullet/BulletCtrl";
import SpawnBullet from "./Bullet/SpawnBullet";

/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-29 22:24
*/
export default class EnemyCtrl extends Laya.Script {

    constructor() {
        super();
        
        /** @prop {name:BulletType, tips:"提示文本", type:string}*/
        this.BulletType="E_B_1";

        this.hp=1;
        this.isCanShoot=false;
        this.spawnTime=this.getRandom(1000,3000);
    }
    Reset(){
        this.isCanShoot=false;
        this.hp=1;
        if(this.owner.visible==false){
            this.owner.visible=true;
            Laya.timer.loop(this.spawnTime,this,this.spawnBullet);
        }
    }
    onAwake(){
        this.spawnPoint=this.owner.getChildByName("spawnPoint");
        Laya.timer.loop(this.spawnTime,this,this.spawnBullet);
    }
    onDisable(){
        Laya.timer.clearAll(this);
    }
    spawnBullet(){
        if(this.isCanShoot){
            this.spawnTime=this.getRandom(1000,3000);
            SpawnBullet.instance.spawn(this.BulletType,this.spawnPoint);
            Laya.SoundManager.playSound("res/Sounds/EnemyShoot.ogg",1);
        }
    }
    onTriggerEnter(other){
        if(this.owner.visible&&other.label=="PB"&&other.owner.visible){
            var demageValue=0;
            if(other.owner.getComponent(BulletCtrl)!=null){
                demageValue=other.owner.getComponent(BulletCtrl).demageValue;
                this.recoverBullet(other.owner);
            }
            else{//散弹
                demageValue=other.owner.parent.getComponent(BulletCtrl).demageValue;
                other.owner.visible=false;
            }
            this.hp-=demageValue;

            if(this.hp<=0){
                this.owner.visible=false;
                this.onDisable();
            }
        }
    }
    /**
     * 回收子弹方法
     * @param {*} bullet 
     */
    recoverBullet(bullet){
        bullet.removeSelf();
        bullet.getComponent(BulletCtrl).onDisable();
        var sign=bullet.getComponent(BulletCtrl).sign;
        Laya.Pool.recover(sign,bullet);
    }
    /**
     * 获取min-max之间的随机数
     * @param {*} min 
     * @param {*} max 
     */
    getRandom(min,max){
        var value=Math.random()*(max-min);
        value=Math.round(value);
        return value+min;
    }
}