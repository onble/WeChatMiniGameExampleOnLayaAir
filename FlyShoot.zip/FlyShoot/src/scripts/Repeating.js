/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-28 16:46
*/
export default class Repeating extends Laya.Script {

    constructor() {
        super();
    }
    onAwake(){
        this.width=this.owner.width;
    }
    onUpdate(){
        if(this.owner.x<=-this.width){
            this.owner.x=this.width;
        }
    }
}