/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-28 16:23
*/
export default class Loading extends Laya.Script {

    constructor() {
        super();
        /** @prop {name:progressBar, tips:"提示文本", type:Node, default:null}*/
        this.progressBar=null;
    }
    onAwake(){
        var source=[
            {url:"res/atlas/CollisionFX/1.atlas",type:Laya.Loader.ATLAS},
            {url:"res/atlas/CollisionFX/2.atlas",type:Laya.Loader.ATLAS},
            {url:"res/atlas/Characters/1/Fly.atlas",type:Laya.Loader.ATLAS},
            {url:"res/atlas/Characters/1/Walk.atlas",type:Laya.Loader.ATLAS},
            {url:"res/atlas/Characters/2/Fly.atlas",type:Laya.Loader.ATLAS},
            {url:"res/atlas/Characters/2/Walk.atlas",type:Laya.Loader.ATLAS},
            {url:"res/atlas/Characters/Smoke.atlas",type:Laya.Loader.ATLAS},
            {url:"res/atlas/Items/Heal.atlas",type:Laya.Loader.ATLAS},
            {url:"res/atlas/Enemy/4.atlas",type:Laya.Loader.ATLAS},
            {url:"res/atlas/Enemy/5.atlas",type:Laya.Loader.ATLAS},
            {url:"res/atlas/Enemy/6.atlas",type:Laya.Loader.ATLAS},
        ]
        Laya.loader.load(source,new Laya.Handler(this,this.loadFinish),new Laya.Handler(this,this.loadProgress));
    }
    loadFinish(){
        Laya.Scene.load("GameScene.json",new Laya.Handler(this,function(scene){
            scene.open();
        }))
    }
    loadProgress(value){
        this.progressBar.value=value;
    }
}