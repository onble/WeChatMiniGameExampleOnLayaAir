import Data from "./Data";
import BgMusic from "./BgMusic";

/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-28 18:10
*/
export default class GameUIManager extends Laya.Script {

    constructor() {
        super();

        this.isCanShoot=true;
        this.timer=0;
        this.time=500;

        //米
        this.meter=0;
        this.gameOver=false;

        this.isCanPause=true;
    }

    onAwake() {
        this.txt_Coin.text=Data.getInstance().getCoinCount();
        this.Init();
        this.InitGameOverDialog();
        this.InitPauseDialog();
    }
    Init(){
        //上升按钮的处理
        this.owner.getChildByName("btn_Up").on(Laya.Event.MOUSE_DOWN,this,function(){
            Laya.stage.event("UpButtonDown");
        })
        this.owner.getChildByName("btn_Up").on(Laya.Event.MOUSE_UP,this,function(){
            Laya.stage.event("UpButtonUp");
        })
        this.owner.getChildByName("btn_Up").on(Laya.Event.MOUSE_OUT,this,function(){
            Laya.stage.event("UpButtonUp");
        })
        Laya.stage.on(Laya.Event.KEY_DOWN,this,function(e){
            if(e.nativeEvent.key=="w"){
                Laya.stage.event("UpButtonDown");
            }
        })
        Laya.stage.on(Laya.Event.KEY_UP,this,function(e){
            if(e.nativeEvent.key=="w"){
                Laya.stage.event("UpButtonUp");
            }
        })

        //射击按钮点击
        this.owner.getChildByName("btn_Shoot").on(Laya.Event.CLICK,this,function(){
            if(this.isCanShoot){
                Laya.stage.event("Shoot");
                this.isCanShoot=false;
            }
        })
        //暂停按钮点击
        this.owner.getChildByName("btn_Pause").on(Laya.Event.CLICK,this,function(){
            this.pauseDialog.visible=true;
            this.isCanPause=false;
            Laya.timer.pause();
        })

        this.txt_Coin=this.owner.getChildByName("coin").getChildByName("txt_Coin");
        Laya.stage.on("AddCoin",this,function(coinCount){
            this.txt_Coin.text=coinCount;
        })

        this.progressbarHp=this.owner.getChildByName("hp");
        Laya.stage.on("Hp",this,function(value){
            this.progressbarHp.value=value;
        })

        this.txt_Meter=this.owner.getChildByName("txt_Meter");
        Laya.timer.loop(500,this,this.AddMeter);
    }
    /**
     * 米数增加
     */
    AddMeter(){
        if(this.gameOver)return;
        this.meter++;
        this.txt_Meter.text=this.meter+"m";
    }
    onDisable(){
        Laya.timer.clearAll(this);
    }
    /**
     * 初始化游戏结束对话框
     */
    InitGameOverDialog(){
        this.gameOverDialog=this.owner.getChildByName("GameOverDialog");
        
        this.gameOverDialog.getChildByName("btn_Restart").on(Laya.Event.CLICK,this,function(){
            this.gameOverDialog.close();
            Laya.Scene.load("GameScene.json",Laya.Handler.create(this,function(scene){
                Laya.timer.resume();
                scene.open();
            }))
        })
        this.gameOverDialog.getChildByName("btn_Menu").on(Laya.Event.CLICK,this,function(){
            this.gameOverDialog.close();
            Laya.Scene.load("Start.json",Laya.Handler.create(this,function(scene){
                Laya.timer.resume();
                scene.open();
            }))
        })
        Laya.stage.on("GameOver",this,this.GameOver);
    }
    /**
     * 初始化暂停对话框
     */
    InitPauseDialog(){
        this.pauseDialog=this.owner.getChildByName("PauseDialog");
        this.pauseDialog.getChildByName("btn_Play").on(Laya.Event.CLICK,this,function(){
            this.isCanPause=true;
            Laya.timer.resume();
            this.pauseDialog.visible=false;
        })
        this.pauseDialog.getChildByName("btn_Restart").on(Laya.Event.CLICK,this,function(){
            Laya.Scene.load("GameScene.json",Laya.Handler.create(this,function(scene){
                Laya.timer.resume();
                scene.open();
            }))
        })
        this.pauseDialog.getChildByName("btn_Menu").on(Laya.Event.CLICK,this,function(){
            Laya.Scene.load("Start.json",Laya.Handler.create(this,function(scene){
                Laya.timer.resume();
                scene.open();
            }))
        })
        
        var soundOn=this.pauseDialog.getChildByName("btn_SoundOn");
        soundOn.on(Laya.Event.CLICK,this,function(){
            soundOff.visible=true;
            soundOn.visible=false;
            Laya.SoundManager.muted=true;
            Data.getInstance().setMute(true);
            BgMusic.SetVolume(0);
        })
        var soundOff=this.pauseDialog.getChildByName("btn_SoundOff");
        soundOff.on(Laya.Event.CLICK,this,function(){
            soundOff.visible=false;
            soundOn.visible=true;
            Laya.SoundManager.muted=false;
            Data.getInstance().setMute(false);
            BgMusic.SetVolume(1);
        })
        //如果是静音
        if(Data.getInstance().getIsMute()){
            soundOn.visible=false;
        }else{
            soundOff.visible=false;
        }
        Laya.SoundManager.muted=Data.getInstance().getIsMute();
    }
    onUpdate(){
        if(this.isCanShoot==false){
            this.timer+=Laya.timer.delta;
            if(this.timer>=this.time){
                this.timer=0;
                this.isCanShoot=true;
            }
        }
    }
    GameOver(){
        this.gameOver=true;
        this.gameOverDialog.visible=true;
        this.gameOverDialog.show();

        this.gameOverDialog.getChildByName("txt_Score").text="Score:"+this.meter;
        if(this.meter>Data.getInstance().getBestScore()){
            Data.getInstance().saveBestScore(this.meter);
            this.gameOverDialog.getChildByName("txt_Best").text="Best:"+this.meter;
        }
        else{
            this.gameOverDialog.getChildByName("txt_Best").text="Best:"+Data.getInstance().getBestScore();
        }
    }
}