import Data from "./Data";
import HintManager from "./HintManager";

/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-27 22:27
*/
export default class ShopPanel extends Laya.Script {

    constructor() {
        super();

        this.selectIndex=0;

        /** @prop {name:txt_Coin, tips:"金币显示文本", type:Node, default:null}*/
        this.txt_Coin=null;
        /** @prop {name:characterList, tips:"人物列表", type:Node, default:null}*/
        this.characterList=null;
        /** @prop {name:buyPanel, tips:"购买界面", type:Node, default:null}*/
        this.buyPanel=null;
    }

    onAwake() {
        this.Init();
        this.readConfigFile();

        this.owner.visible=false;
    }
    Init(){
        this.txt_Coin.text=Data.getInstance().getCoinCount();
        this.characterList.scrollBar.hide=true;
        this.characterList.renderHandler=new Laya.Handler(this,this.renderHandler);
        this.characterList.mouseHandler=new Laya.Handler(this,this.mouseHandler);

        this.buyPanel.close();
        this.buyPanel.closeHandler=new Laya.Handler(this,this.buyPanelCloseHandler)

        Laya.stage.on("ShowShopPanel",this,function(){
            this.owner.visible=true;
        })
        this.owner.getChildByName("btn_Menu").on(Laya.Event.CLICK,this,function(){
            this.owner.visible=false;
            Laya.stage.event("ShowStartPanel");
        })
        this.owner.getChildByName("btn_Left").on(Laya.Event.CLICK,this,function(){
            this.characterList.tweenTo(this.characterList.scrollBar.value/497-1,300);
        })
        this.owner.getChildByName("btn_Right").on(Laya.Event.CLICK,this,function(){
            this.characterList.tweenTo(this.characterList.scrollBar.value/497+1,300);
        })
    }

    /**
     * 读取人物皮肤配置文件
     */
    readConfigFile(){
        var infoArr=[];
        Laya.loader.load("res/CharacterSkinConfig.txt",new Laya.Handler(this,function(configFile){
            var itemArr=configFile.split('\n');
            itemArr.forEach(element => {
                var arr=element.split(' ');
                var info=null;
                info={
                    iconPath:arr[0],
                    price:arr[1],
                    name:arr[2]
                }
                infoArr.push(info);
            });
            this.characterList.array=infoArr;
        }))
    }
    /**
     * 单元格渲染处理器处理函数
     */
    renderHandler(cell,index){
        cell.getChildByName("img_Skin").skin=cell.dataSource.iconPath;
        cell.getChildByName("txt_Name").text=cell.dataSource.name;
        cell.getChildByName("price").getChildByName("txt_Price").text=cell.dataSource.price;

        //如果购买
        if(Data.getInstance().isBuySkin(index)){
            cell.getChildByName("price").visible=false;
            cell.getChildByName("txt_Name").visible=true;
        }else{
            cell.getChildByName("price").visible=true;
            cell.getChildByName("txt_Name").visible=false;
        }
        if(Data.getInstance().getChooseSKinIndex()==index){
            cell.getChildByName("img_Choose").visible=true;
        }else{
            cell.getChildByName("img_Choose").visible=false;
        }
    }
    /**
     * 鼠标事件的监听
     * @param {*} e 
     * @param {*} index 
     */
    mouseHandler(e,index){
        if(e.type==Laya.Event.MOUSE_UP){
            this.selectIndex=index;
            if(Data.getInstance().isBuySkin(index)){
                //把之前的皮肤设置为不选择
                var lastCell=this.characterList.getCell(Data.getInstance().getChooseSKinIndex());
                if(lastCell!=null)
                    lastCell.getChildByName("img_Choose").visible=false;

                //使用这个皮肤
                Data.getInstance().useSkin(index);
                this.characterList.getCell(index).getChildByName("img_Choose").visible=true;
            }else{
                //弹出购买界面
                this.buyPanel.show();
            }
        }
    }
    /**
     * 购买对话框关闭按钮的事件处理
     * @param {*} btnName 
     */
    buyPanelCloseHandler(btnName){
        if(btnName=="no"){
            this.buyPanel.close();
        }
        else if(btnName=="ok"){
            //购买
            var price=this.characterList.getCell(this.selectIndex).dataSource.price;
            if(Data.getInstance().buySkin(this.selectIndex,price)){
                var lastCell=this.characterList.getCell(Data.getInstance().getChooseSKinIndex());
                if(lastCell!=null)
                    lastCell.getChildByName("img_Choose").visible=false;

                var cell=this.characterList.getCell(this.selectIndex);
                cell.getChildByName("price").visible=false;
                cell.getChildByName("txt_Name").visible=true;
                cell.getChildByName("img_Choose").visible=true;

                Data.getInstance().useSkin(this.selectIndex);

                this.txt_Coin.text=Data.getInstance().getCoinCount();
            }
            else{
                //弹出提示信息，购买失败，金币不足
                HintManager.Show("金币不足");
            }

            this.buyPanel.close();
        }
    }
}