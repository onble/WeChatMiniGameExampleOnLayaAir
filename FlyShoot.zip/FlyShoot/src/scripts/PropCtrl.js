/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-31 11:23
*/
export default class PropCtrl extends Laya.Script {

    constructor() {
        super();
    }
    onTriggerExit(other){
        if(other.label=="LeftCollider"){
            this.owner.visible=false;
        }
    }
}