import BulletMove from "./BulletMove";

/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-29 11:24
*/
export default class BulletCtrl extends Laya.Script {

    constructor() {
        super();
        this.demageValue=0;
        this.sign=null;
    }
    Init(sign,desTime,moveSpeed,demageValue){
        this.demageValue=demageValue;
        this.sign=sign;

        Laya.timer.once(desTime,this,function(){
            this.owner.removeSelf();
            Laya.Pool.recover(sign,this.owner);
        })

        //单个子弹
        if(this.owner.numChildren==0){
            this.owner.visible=true;
            this.owner.getComponent(BulletMove).Init(moveSpeed);
            return;
        }
        var rotation=-20;
        //遍历散弹所有子物体，进行reset
        for(var i=0;i<this.owner.numChildren;i++){
            this.owner.getChildAt(i).visible=true;
            this.owner.getChildAt(i).x=0;
            this.owner.getChildAt(i).y=0;
            if(rotation==0){
                this.owner.getChildAt(i).rotation=0.01;
            }
            else
                this.owner.getChildAt(i).rotation=rotation;
            rotation+=5;
            this.owner.getChildAt(i).getComponent(BulletMove).Init(moveSpeed);
        }
    }
    onDisable(){
        Laya.timer.clearAll(this);
    }
}