/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-29 12:02
*/
export default class BulletMove extends Laya.Script {

    constructor() {
        super();
    }
    Init(speed){
        Laya.timer.clearAll(this);
        
        this.moveX=Math.cos(this.owner.rotation*Math.PI/180)*speed;
        this.moveY=Math.sin(this.owner.rotation*Math.PI/180)*speed;
        Laya.timer.frameLoop(1,this,this.frameLoop);
    }
    frameLoop(){
        this.owner.x+=this.moveX;
        this.owner.y+=this.moveY;
    }
    onDisable(){
        Laya.timer.clear(this,this.frameLoop);
    }
}