/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-30 14:08
*/
export default class PBEB extends Laya.Script {

    constructor() {
        super();
    }
    onTriggerEnter(other){
        if(other.label=="PB"&&other.owner.visible&&this.owner.visible){
            other.owner.visible=false;
            this.owner.visible=false;
        }
    }
}