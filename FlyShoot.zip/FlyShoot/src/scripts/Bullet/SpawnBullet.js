import BulletCtrl from "./BulletCtrl";

/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-29 10:59
*/
export default class SpawnBullet{
    /**
     * 预加载预制体
     */
    preLoad(){
        Laya.loader.load("prefab/P_B_1.json",new Laya.Handler(this,function(pre){
            this.P_B_1=pre;
        }),null,Laya.Loader.PREFAB);
        Laya.loader.load("prefab/P_B_2.json",new Laya.Handler(this,function(pre){
            this.P_B_2=pre;
        }),null,Laya.Loader.PREFAB);
        Laya.loader.load("prefab/E_B_1.json",new Laya.Handler(this,function(pre){
            this.E_B_1=pre;
        }),null,Laya.Loader.PREFAB);
        Laya.loader.load("prefab/E_B_2.json",new Laya.Handler(this,function(pre){
            this.E_B_2=pre;
        }),null,Laya.Loader.PREFAB);
    }
    spawn(type,spawnPoint){
        switch(type){
            case "P_B_1":
                this.creatBullet(type,this.P_B_1,spawnPoint,15,0.5,3000);
                break;
            case "P_B_2":
                this.creatBullet(type,this.P_B_2,spawnPoint,18,1,3000);
                break;
            case "E_B_1":
                this.creatBullet(type,this.E_B_1,spawnPoint,18,0.1,4000);
                break;
            case "E_B_2":
                this.creatBullet(type,this.E_B_2,spawnPoint,18,0.1,4000);
                break;
            default:
                console.log(type);
                break;
        }
    }
    creatBullet(sign,prefab,spawnPoint,moveSpeed,demageValue,desTime){
        var bullet=Laya.Pool.getItemByCreateFun(sign,function(){
            var temp=prefab.create();
            return temp;
        },this);
        Laya.stage.getChildAt(0).getChildAt(0).addChild(bullet);
        var point=spawnPoint.parent.localToGlobal(new Laya.Point(spawnPoint.x,spawnPoint.y))
        bullet.pos(point.x,point.y);
        bullet.getComponent(BulletCtrl).Init(sign,desTime,moveSpeed,demageValue);
    }
}
SpawnBullet.instance=new SpawnBullet();