import EffectAutoHide from "./EffectAutoHide";

/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-29 15:18
*/
export default class EffectManager extends Laya.Script {

    constructor() {
        super();
    }
    onAwake(){
        for(var i=0;i<this.owner.numChildren;i++){
            this.owner.getChildAt(i).addComponent(EffectAutoHide);
        }
    }
    Show(posx,posy){
        for(var i=0;i<this.owner.numChildren;i++){
            if(this.owner.getChildAt(i).visible==false){
                this.owner.getChildAt(i).visible=true;
                this.owner.getChildAt(i).pos(posx,posy);
                break;
            }
        }
    }
}