/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-28 16:44
*/
export default class AutoMove extends Laya.Script {

    constructor() {
        super();
        this.moveSpeed=7;
    }
    onAwake(){
        Laya.timer.frameLoop(1,this,this.frameLoop);
    }
    frameLoop(){
        if(this.owner.visible)
            this.owner.x-=this.moveSpeed;
    }
    onDisable(){
        Laya.timer.clear(this,this.frameLoop);
    }
}