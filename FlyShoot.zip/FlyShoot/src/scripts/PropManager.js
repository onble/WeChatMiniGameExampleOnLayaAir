import AutoMove from "./AutoMove";
import PropCtrl from "./PropCtrl";

/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-31 11:03
*/
export default class PropManager extends Laya.Script {

    constructor() {
        super();
        this.randomTime=this.getRandom(1000,3000);
    }

    onAwake() {
        for(var i=0;i<this.owner.numChildren;i++){
            this.owner.getChildAt(i).visible=false;
            this.owner.getChildAt(i).addComponent(AutoMove).moveSpeed=12;
            this.owner.getChildAt(i).addComponent(PropCtrl);
        }

        Laya.timer.loop(this.randomTime,this,this.showProp);
    }
    onDisable(){
        Laya.timer.clearAll(this);
    }
    showProp(){
        this.randomTime=this.getRandom(1000,3000);
        
        var index=this.getRandom(0,this.owner.numChildren-1);
        var prop=this.owner.getChildAt(index);
        if(prop.visible==false){
            prop.visible=true;
            prop.pos(2100,this.getRandom(200,800));
        }
    }
    /**
     * 获取min-max之间的随机数
     * @param {*} min 
     * @param {*} max 
     */
    getRandom(min,max){
        var value=Math.random()*(max-min);
        value=Math.round(value);
        return value+min;
    }
}