import BgMusic from "./BgMusic";

/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-27 21:37
*/
export default class StartPanel extends Laya.Script {

    constructor() {
        super();
    }

    onAwake() {
        this.owner.getChildByName("btn_Start").on(Laya.Event.CLICK,this,this.StartButtonClick);
        this.owner.getChildByName("btn_Shop").on(Laya.Event.CLICK,this,this.ShopButtonClick);

        Laya.stage.on("ShowStartPanel",this,function(){
            this.owner.visible=true;
        })

        BgMusic.Play();
    }
    StartButtonClick(){
        //处理开始按钮点击
        Laya.Scene.open("Loading.json");
    }
    ShopButtonClick(){
        this.owner.visible=false;
        //处理商店按钮点击
        Laya.stage.event("ShowShopPanel");
    }
}