import Obstacle from "./Obstacle";
import EnemyCtrl from "./EnemyCtrl";

/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-29 13:37
*/
export default class ObstacleCtrl extends Laya.Script {

    constructor() {
        super();

        this.childArr=[];
    }

    /**
     * 重置属性
     */
    Reset(){
        this.owner.x=this.initX;
        this.owner.y=this.initY;

        for(var i=0;i<this.childArr.length;i++){
            if(this.childArr[i].getComponent(EnemyCtrl)!=null){
                this.childArr[i].getComponent(EnemyCtrl).Reset();
            }
            this.childArr[i].visible=true;
        }
    }
    Show(){
        for(var i=0;i<this.childArr.length;i++){
            if(this.childArr[i].getComponent(EnemyCtrl)!=null){
                this.childArr[i].getComponent(EnemyCtrl).isCanShoot=true;
            }
        }
    }
    onAwake() {
        this.getAllChild(this.owner);

        for(var i=0;i<this.childArr.length;i++){
            this.childArr[i].addComponent(Obstacle);
        }

        this.initX=this.owner.x;
        this.initY=this.owner.y;
    }
    /**
     * 获取所有子物体
     * @param {*} parent 
     */
    getAllChild(parent){
        if(parent.numChildren>0){
            for(var i=0;i<parent.numChildren;i++){
                if(parent.getChildAt(i).getComponent(Laya.RigidBody)!=null)
                    this.childArr.push(parent.getChildAt(i));
                this.getAllChild(parent.getChildAt(i));
            }
        }
    }
}