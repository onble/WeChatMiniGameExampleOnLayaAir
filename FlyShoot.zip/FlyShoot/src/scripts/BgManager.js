/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-30 21:32
*/
export default class BgManager extends Laya.Script {

    constructor() {
        super();
    }

    onAwake() {
        var path="Background/"+this.getRandom(1,4)+"/Repeated.png";
        for(var i=0;i<this.owner.numChildren;i++){
            this.owner.getChildAt(i).texture=path;
            //this.owner.getChildAt(i).loadImage(path);
        }
    }
    /**
     * 获取min-max之间的随机数
     * @param {*} min 
     * @param {*} max 
     */
    getRandom(min,max){
        var value=Math.random()*(max-min);
        value=Math.round(value);
        return value+min;
    }
}