/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-28 14:07
*/
let hintPre=null;
export default class HintManager{
    static Show(text){
        if(hintPre==null){
            Laya.loader.load("prefab/HintPre.json",new Laya.Handler(this,function(pre){
                hintPre=pre;
                this.Create(text);
            }),null,Laya.Loader.PREFAB);
        }else{
            this.Create(text);
        }
    }
    /**
     * 生成预制体
     * @param {*} text 
     */
    static Create(text){
        var hintTemp=Laya.Pool.getItemByCreateFun("Hint",this.creatFun,this);
        Laya.stage.addChild(hintTemp);
        hintTemp.text=text;
        hintTemp.pos(478,441);
        Laya.Tween.to(hintTemp,{y:441-300},500,Laya.Ease.backInOut,new Laya.Handler(this,function(){
            hintTemp.removeSelf();
            Laya.Pool.recover("Hint",hintTemp);
        }),100);
    }
    static creatFun(){
        return hintPre.create();
    }
}