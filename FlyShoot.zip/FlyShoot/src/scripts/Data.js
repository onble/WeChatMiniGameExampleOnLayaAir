/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-27 22:29
*/
export default class Data extends Laya.Script {

    constructor() {
        super();
        this.instance=null;
        
        this.coinCount=Number(Laya.LocalStorage.getItem("CoinCount"));
        if(Laya.LocalStorage.getItem("CoinCount")==null)
        this.coinCount=1000;

        this.chooseSkinIndex=Number(Laya.LocalStorage.getItem("ChooseSkinIndex"));
        //默认皮肤
        if(Laya.LocalStorage.getItem("ChooseSkinIndex")==null) this.useSkin(0);
    }
    static getInstance(){
        if(this.instance==null){
            this.instance=new Data();
        }
        return this.instance;
    }
    /**
     * 获取金币数量
     */
    getCoinCount(){
        return this.coinCount;
    }
    //增加金币数量
    addCoinCount(value=1){
        this.coinCount+=value;
        Laya.LocalStorage.setItem("CoinCount",this.coinCount);

        return this.coinCount;
    }
    /**
     * 皮肤是否购买
     * @param {*} index 
     */
    isBuySkin(index){
        var temp=Number(Laya.LocalStorage.getItem("Character"+index))
        return temp==1?true:false;
    }
    /**
     * 购买皮肤
     * @param {*皮肤的下标} index 
     * @param {*价格} price 
     */
    buySkin(index,price){
        //判断当前金币数量是否可以购买
        if(price<=this.coinCount){
            //可以购买
            this.addCoinCount(-price);
            Laya.LocalStorage.setItem("Character"+index,1);
            return true;
        }
        return false;
    }
    /**
     * 获取选择的皮肤下标
     */
    getChooseSKinIndex(){
        return this.chooseSkinIndex;
    }
    /**
     * 使用这个皮肤
     * @param {*} index 
     */
    useSkin(index){
        this.chooseSkinIndex=index;
        Laya.LocalStorage.setItem("ChooseSkinIndex",index);
        Laya.LocalStorage.setItem("Character"+index,1);
    }
    getBestScore(){
        return Number(Laya.LocalStorage.getItem("BestScore"));
    }
    saveBestScore(score){
        Laya.LocalStorage.setItem("BestScore",score);
    }
    setMute(value){
        var isMute=value==true?1:0;
        Laya.LocalStorage.setItem("Mute",isMute);
    }
    getIsMute(){
        var isMute=Number(Laya.LocalStorage.getItem("Mute"))
        return isMute==1?true:false;
    }
}