import ObstacleCtrl from "./ObstacleCtrl";

/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-30 15:44
*/
export default class ObstacleManager extends Laya.Script {

    constructor() {
        super();
    }

    onStart() {
        for(var i=0;i<this.owner.numChildren;i++){
            this.owner.getChildAt(i).visible=false;
        }
        this.showObstacle();

        Laya.stage.on("ShowObstacle",this,this.showObstacle);
    }
    showObstacle(){
        var value=this.getRandom(0,300);
        var index=0;
        if(value>200){
            index=2;
        }else if(value>100){
            index=1;
        }else{
            index=0;
        }
        var ob=this.owner.getChildAt(index);
        if(ob.visible==false){
            //可以使用
            ob.visible=true;
            ob.getComponent(ObstacleCtrl).Show();
        }
    }
    /**
     * 获取min-max之间的随机数
     * @param {*} min 
     * @param {*} max 
     */
    getRandom(min,max){
        var value=Math.random()*(max-min);
        value=Math.round(value);
        return value+min;
    }
}