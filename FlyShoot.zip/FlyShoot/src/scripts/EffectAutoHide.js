/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-29 15:22
*/
export default class EffectAutoHide extends Laya.Script {

    constructor() {
        super();
    }
    onUpdate(){
        //代表动画播放完了
        if(this.owner.index==this.owner.count-1){
            this.owner.visible=false;
            this.owner.index=0;
        }
    }
}