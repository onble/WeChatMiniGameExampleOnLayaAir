import ObstacleCtrl from "./ObstacleCtrl";

/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-30 15:58
*/
export default class LeftCollider extends Laya.Script {

    constructor() {
        super();
    }
    onTriggerExit(other){
        if(other.label=="OB"){
            other.owner.parent.getComponent(ObstacleCtrl).Reset();
            other.owner.parent.visible=false;
            Laya.stage.event("ShowObstacle");
        }
    }
}