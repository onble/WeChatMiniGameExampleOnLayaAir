/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-29 13:36
*/
export default class Obstacle extends Laya.Script {

    constructor() {
        super();
    }

    onAwake() {
        this.initX=this.owner.x;
        this.initY=this.owner.y;
    }
    onUpdate(){
        this.owner.x=this.initX;
        this.owner.y=this.initY;
    }
}