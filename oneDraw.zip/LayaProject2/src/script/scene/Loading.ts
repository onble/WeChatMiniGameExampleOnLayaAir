
const { regClass } = Laya;
import windowUse from "./windowUse";
import GameFIG_Get from "../GameFIG/GameFIG_Get.js";
import { GameFIG_Config } from "../GameFIG/GameFIG_Config.js";
import { LoadingBase } from "./Loading.generated";
@regClass()
export class Loading extends LoadingBase {
    LoadMuch: number;
    loadNow: number;
    LiteTime: { star: number; end: number; };
    GameFIG = GameFIG_Get.Get();
    windowUser: windowUse = windowUse.Get();

    constructor() {
        super();



    }
    onEnable() {
        
        this.LoadFist();
        Laya.InputManager.multiTouchEnabled = false;


    }
    Loadother() {
        this.LoadMuch = 6;
        this.loadNow = 0;
        this.LoadLitePlay(120, 1);
        this.GameFIG.Main_Use(new Laya.Handler(this, () => {
            this.LoadAdd("Main_use_Login", 1);
        }, []), new Laya.Handler(this, () => {
            this.LoadAdd("Main_use_GetMain", 1);
        }, [], true));
        this.windowUser.LoadMapConfig(Laya.Handler.create(this, this.LoadAdd, ["LoadJson", 1]))
        for (var a = 0; a < 4; a++) {
            var Texture = new Laya.Texture();
            this.windowUser.drawTexture.push(Texture);
            Texture.load("Img/draw/" + a + ".png", Laya.Handler.create(this, this.LoadAdd, ["Texture" + a, 1]));
        }
  
    }
    /**
 * 预留加载时间 卡加载时长专用
 * @param {*} time 卡多久 毫秒制
 * @param {*} speed 更新执行速度 毫秒制 非0正整数 越小进度越平滑
 */
    LoadLitePlay(time: any = 0, speed: any = 0): void {
        this.LiteTime = { star: 0, end: time };
        Laya.timer.loop(speed, this, this.LoadLite, []);
        this.LoadMuch += Math.ceil(time / speed);
    }
    //lite 执行
    LoadLite() {
        this.LiteTime.star++;
        if (this.LiteTime.star == this.LiteTime.end) {
            Laya.timer.clear(this, this.LoadLite);
        }
        this.LoadAdd(null, 1);
    }
    LoadFist() {

        this.Loadother();
    }


    LoadAdd(name = "", much = 1) {
        this.loadNow += much;
        if (this.loadNow == this.LoadMuch) {//加载完毕
            this.GotoGame();
        }
        this.loadRes(this.loadNow / this.LoadMuch);
        if (name)
            console.log("已经加载:" + name);
    }
    GotoGame() {
        Laya.Scene.open(this.windowUser.viewAll.Main, false, {}, new Laya.Handler(this, this.close));
    }

    loadRes(res: number) {
        this.LoadLab.text = "正在加载:" + (Math.floor(res * 100)) + "%";

    }

}