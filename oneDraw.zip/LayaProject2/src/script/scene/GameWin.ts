const { regClass, property } = Laya;
import { GameWinBase } from "./GameWin.generated";
import GameFIG_Get from "../GameFIG/GameFIG_Get.js";
import { GameFIG_Config } from "../GameFIG/GameFIG_Config.js";


@regClass()
export class GameWin extends GameWinBase {
    GameFIG = GameFIG_Get.Get();
    onEnable(): void {
        Laya.Tween.from(this.Win, { scaleX: 0.5, scaleY: 0.5 }, 500, Laya.Ease.backOut, Laya.Handler.create(this, () => {
            Laya.Tween.to(this.hua1, { x: 45, y: 435 }, 300, Laya.Ease.quadIn);
            Laya.Tween.to(this.hua2, { x: 736, y: 460 }, 300, Laya.Ease.quadIn);
            Laya.Tween.to(this.GameBack, { alpha: 1 }, 500, Laya.Ease.quadIn);

        }))
        this.Addbut();
    }
    OpenDmsg: any;
    onOpened(param: any): void {
        this.OpenDmsg = param;
    }
    Addbut() {

        this.GameFIG.butTween(this.close_but, Laya.Handler.create(this, () => {
            this.OpenDmsg.GameUI_.GameNext();
            this.close();
        }, [], false), 2, true);

        this.GameFIG.butTween(this.GameBack, Laya.Handler.create(this, () => {
            this.OpenDmsg.GameUI_.GameReture();
            this.close();
        }, [], false), 2, true);
        this.GameFIG.butTween(this.close_but, Laya.Handler.create(this, this.GetToNext, [1], false), 2, true);
        this.GameFIG.butTween(this.DouGet, Laya.Handler.create(this, () => {
            this.GameFIG.GG_all(true, Laya.Handler.create(this, this.GetToNext, [2]), Laya.Handler.create(this, this.GetToNext, [1]));
        }, [1], false), 2, true);

    }
    GetToNext(much: number) {
        GameFIG_Config.player_Config.TS += much;
        GameFIG_Config.player_Config.YS += much;
        this.GameFIG.UpdatePlayerMsg();
        this.OpenDmsg.GameUI_.UpdateZJM();
        this.OpenDmsg.GameUI_.GameNext();
        this.close();
    }

}