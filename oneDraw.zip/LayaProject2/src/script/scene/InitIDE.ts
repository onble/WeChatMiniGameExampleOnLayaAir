const { regClass, property } = Laya;

@regClass()
export class InitIDE extends Laya.Script {
    constructor() {
        super();
    }
    @property(Laya.Prefab)
    public QuanPre: Laya.Prefab;
}