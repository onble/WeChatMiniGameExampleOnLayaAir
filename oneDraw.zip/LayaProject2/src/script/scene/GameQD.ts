const { regClass, property } = Laya;
import { GameQDBase } from "./GameQD.generated";
import { GameFIG_Config } from "../GameFIG/GameFIG_Config.js";
import GameFIG_Get from "../GameFIG/GameFIG_Get.js";
import windowUse from "./windowUse.js";


@regClass()
export class GameQD extends GameQDBase {
    constructor() {
        super();

    }
    GameFIG = GameFIG_Get.Get();
    windowUser: windowUse = windowUse.Get();

    onEnable() {
        Laya.Tween.from(this.ImgT, { scaleX: .5, scaleY: .5 }, 400, Laya.Ease.backOut);
        this.UpdateThis();
        if (GameFIG_Config.player_Config.QD.day < 7 && !this.GameFIG.TFdate(new Date(), new Date(GameFIG_Config.player_Config.QD.LastDay))) {
            this.DouGet.visible = true;
            this.Get.visible = true;

        } else {
            this.DouGet.visible = false;
            this.Get.visible = false;
        }
        this.Addbut();
    }
    onOpened(param: any): void {
        this.OpenDmsg = param;
    }
    OpenDmsg: any;
    QDGame(tfdou: boolean) {
        if (GameFIG_Config.player_Config.QD.day < 7 && !this.GameFIG.TFdate(new Date(), new Date(GameFIG_Config.player_Config.QD.LastDay))) {
            if (tfdou) {
                this.GameFIG.GG_all(true, new Laya.Handler(this, this.GetQd, [2]), new Laya.Handler(this, this.GetQd, [1]));
            } else {
                this.GetQd(1);
            }
        } else {
            this.GameFIG.TiShiKuang("已全部签到");
        }

    }
    GetQd(much: number) {
        var config = this.windowUser.QDconfig[GameFIG_Config.player_Config.QD.day];
        for (var a = 0; a < config.key.length; a++) {
            GameFIG_Config.player_Config[config.key[a]] += config.much * much;
        }
        GameFIG_Config.player_Config.QD.day++;
        GameFIG_Config.player_Config.QD.LastDay = new Date();
        this.GameFIG.UpdatePlayerMsg();
        this.OpenDmsg.mythis.UpdateZJM();
        this.GameFIG.TiShiKuang("签到成功");
        this.DouGet.visible = false;
        this.Get.visible = false;
        this.UpdateThis();
    }

    UpdateThis() {
        this.QD_lb.text = "已累计签到" + (GameFIG_Config.player_Config.QD.day) + "天"
        var arr = [
            this.day0,
            this.day1,
            this.day2,
            this.day3,
            this.day4,
            this.day5,
            this.day6,
        ]
        for (var a = 0; a < 7; a++) {
            if (a < GameFIG_Config.player_Config.QD.day) {
                (arr[a].getChildByName("1") as Laya.Image).visible = true;
                (arr[a].getChildByName("2") as Laya.Image).visible = true;
            } else {
                (arr[a].getChildByName("1") as Laya.Image).visible = false;
                (arr[a].getChildByName("2") as Laya.Image).visible = false;
            }
        }
    }
    Addbut() {
        this.GameFIG.butTween(this.close_but, new Laya.Handler(this, this.close, [], false), 2, true);
        this.GameFIG.butTween(this.Get, new Laya.Handler(this, this.QDGame, [false], false), 2, true);
        this.GameFIG.butTween(this.DouGet, new Laya.Handler(this, this.QDGame, [true], false), 2, true);
    }

}