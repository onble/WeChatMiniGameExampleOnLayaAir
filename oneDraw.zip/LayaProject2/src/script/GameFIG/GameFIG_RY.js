

import { GameFIG_Config } from "./GameFIG_Config";
import GameFIG_WX from "./GameFIG_WX";
/**游戏工具类_华为荣耀 */
export class GameFIG_RY extends GameFIG_WX {
    constructor() { //请务必设置这里面的参数
        super();
        this.nowtp = 0;
        GameFIG_RY.instance = this;
        this.wx = Laya.Browser.window.qg;
        this.TFOpenGame = {};
    }
    /**
      *  Get 单例获取工具类
      * @return {GameFIG_RY} 
      */
    static Get() {
        if (GameFIG_RY.instance == undefined) {
            GameFIG_RY.instance = new GameFIG_RY();
        }
        return GameFIG_RY.instance;
    }
    WXLogin() {
        this.LoadSuccess_Fun.runWith(GameFIG_Config.player_Config);
        return;//后续需要接入登录打开后半段 暂时不用

    }
    /**添加到桌面按钮 */
    AddDesktop() {
        if (this.wx && this.wx.hasShortcutInstalled && this.wx.installShortcut) {
            this.wx.hasShortcutInstalled({//原生测试  注意打包后添加不了 大部分是打包logo错误引发
                success: function (status) {
                    if (status) {
                        GameFIG_RY.instance.TiShiKuang("已添加");
                    } else {
                        GameFIG_RY.instance.wx.installShortcut({
                            success: function () {
                                console.log('创建成功')
                                GameFIG_RY.instance.TiShiKuang("添加成功");
                            },
                            fail: function (res) {
                                console.log('创建失败', res)
                                GameFIG_RY.instance.TiShiKuang("添加失败");
                            },
                        })
                    }
                }
            })
        } else {
            this.TiShiKuang("暂不支持")
        }

    }
    /**banner展示 */
    bannershow() {
        this.LoadYuan();
        // if (this.wx) {
        //     this.loadCanshowB = false;
        //     if (!this.banner) {
        //         this.bannerVivo = false;
        //         this.JtGG();
        //     } else if (this.bannerVivo) {
        //         this.banner.show().then(() => {
        //             console.log('banner广告展示完成');
        //             GameFIG_RY.instance.bannerVivo = false;
        //         }).catch((err) => {
        //             console.log('banner广告展示失败', JSON.stringify(err));
        //             GameFIG_RY.instance.banner = null;
        //             GameFIG_RY.instance.bannerVivo = false;
        //             GameFIG_RY.instance.JtGG()
        //             //  GameFIG_this.TiShiKuang("errCode2:"+err.errCode)
        //         })
        //     } else if (this.LoadBanner) {
        //         this.loadCanshowB = true;
        //     }

        // }

    }
    changgebanner(width = 300, TFshow = false) {//重写方便适应老项目
        if (TFshow) {
            this.bannershow();
        }
    }
    hidebanner() {//重写 方便适应老项目
        // if (this.wx) {
        //     if (this.banner) {
        //         this.banner.hide();
        //         this.bannerVivo = true;
        //     }
        // }
        this.HideYuan();
    }
    /**
     * 插屏广告展示 
     * @param {*} PicOrSp 视频还是图片 false 图片
     * @param {*} ttff 是否根据启动时间显示
     */
    InterShow(PicOrSp = false, ttff = false) {
        if (this.wx && ((ttff && this.TFOpenGG("inter")) || (!ttff))) {
            console.log("正在展示Inter")
            if (this.interstitialAd) {
                this.interstitialAd.destroy();
            }
            this.interstitialAd = this.wx.createInterstitialAd({
                adUnitId: PicOrSp ? GameFIG_Config.GameGGConfig.Ry.ChaPinVedio : GameFIG_Config.GameGGConfig.Ry.ChaPin
            });
            this.interstitialAd.onClose(err => {
                Laya.SoundManager.muted = false;
                GameFIG_RY.instance.PlayMusic(0);
                //   GameFIG_RY.instance.bannershow();
                //  GameFIG_RY.instance.interMask.removeSelf();
            });
            this.interstitialAd.onError(err => {
                console.log("插屏广告加载失败", err);
                // GameFIG_RY.instance.interMask.removeSelf();
            });
            this.interstitialAd.onShow(() => {
                Laya.SoundManager.muted = true;
                console.log('插屏广告展示完成');
                //   GameFIG_RY.instance.hidebanner();
            })
            this.interstitialAd.onLoad(() => {
                GameFIG_RY.instance.interstitialAd.show()
            });

            this.interstitialAd.load();
        }

    }
    LoadYuan() {
        if (!this.wx) { return }
        if (this.wx.createNativeAd) {
            if (this.customAd) {
                this.customAd.destroy();
            }
            console.log("正在加载原生");
            if (!this.BackYImg) {
                this.BackYImg = new Laya.Image();
                this.BackYImg.skin = "q_ad/bannerNativeBg.png";
                this.BackYImg.zOrder = 999;
                this.BackYImg.sizeGrid = "25,25,25,25";
            }

            this.customAd = this.wx.createNativeAd({
                adUnitId: GameFIG_Config.GameGGConfig.Ry.CunTu,
                style: {
                    gravity: "bottom|center_horizontal"
                }
            });

            this.customAd.onClose(err => {
                GameFIG_RY.instance.BackYImg.removeSelf();
            });
            this.customAd.onResize(res => {
                console.log("正在设置backimg位置")
                GameFIG_RY.instance.BackYImg.width = res.width / this.GetSystermInfo().windowWidth * Laya.stage.width;
                GameFIG_RY.instance.BackYImg.height = res.height / this.GetSystermInfo().windowHeight * Laya.stage.height;
                GameFIG_RY.instance.BackYImg.x = res.left / this.GetSystermInfo().windowWidth * Laya.stage.width;
                GameFIG_RY.instance.BackYImg.y = res.top / this.GetSystermInfo().windowHeight * Laya.stage.height;
            })
            this.customAd.onShow(err => {
                Laya.stage.addChild(GameFIG_RY.instance.BackYImg);

            })
            this.customAd.onLoad(err => {
                GameFIG_RY.instance.customAd.show();

            })


            this.customAd.onError(err => {
                console.log("原生模板广告加载失败", err);


            });
            this.customAd.load();
        }
    }
    HideYuan() {
        if (this.customAd) {
            this.customAd.destroy();
            this.customAd = null;
            this.BackYImg.removeSelf();
        }
    }
    JtGG(width = 300) { //图片广告
        if (GameFIG_Config.GameGGConfig.TPid.length == 0) {
            return;
        }

        if (this.TFOpenGG()) { //id不为空时
            this.LoadBanner = true;
            console.log("正在创建banner")
            this.banner = this.wx.createBannerAd({
                adUnitId: GameFIG_Config.GameGGConfig.TPid[this.nowtp],
                style: {
                    gravity: "bottom|center_horizontal"//底部居中
                }
            })
            this.banner.onResize(res => {
                console.log("更新位置:" + JSON.stringify(res));//left top width height
            })
            this.banner.onClose(res => {
                GameFIG_RY.instance.LoadBanner = false;
                GameFIG_RY.instance.banner = null;
                GameFIG_RY.instance.bannerVivo = false;
                GameFIG_RY.instance.JtGG();
            })
            this.banner.onHide(res => {
                //用户主动隐藏--或者其他方式隐藏
                GameFIG_RY.instance.bannerVivo = true;
            })

            this.banner.onLoad(res => {
                GameFIG_RY.instance.LoadBanner = false;
                console.log("banner广告加载成功");
                GameFIG_RY.instance.bannerVivo = true;
                if (GameFIG_RY.instance.loadCanshowB) {
                    GameFIG_RY.instance.bannershow();
                }
            })
            this.banner.onError(err => {
                GameFIG_RY.instance.LoadBanner = false;
                GameFIG_RY.instance.bannerVivo = false;
                GameFIG_RY.instance.banner = null;
                console.log("创建banner失败 " + err.errCode)
                //   GameFIG_this.TiShiKuang("errCode1:"+err.errCode)
            })
            this.banner.load();
        } else { }

    }
    dtgg() { //视频广告v

        if (GameFIG_Config.GameGGConfig.SPid && this.TFOpenGG()) {
            this.redio = this.wx.createRewardedVideoAd({
                adUnitId: GameFIG_Config.GameGGConfig.SPid,

            });
            this.redio.onLoad(() => {
                GameFIG_RY.instance.readtf = true;
                console.log("视频广告加载完毕");
            })

            this.redio.onError(err => {
                GameFIG_RY.instance.readtf = false;
                GameFIG_RY.instance.TVorShare = false;
                // GameFIG_this.TiShiKuang("视频加载失败");
                if (GameFIG_RY.instance.fail_HanderUse) {
                    GameFIG_RY.instance.fail_HanderUse.run();
                    GameFIG_RY.instance.fail_HanderUse = undefined;

                }
                if (GameFIG_RY.instance.success_HanderUse) {
                    GameFIG_RY.instance.success_HanderUse = undefined;
                    Laya.SoundManager.muted = false;
                    GameFIG_RY.instance.PlayMusic(0);
                }

            })
            this.redio.onReward(res => {
                Laya.SoundManager.muted = false;
                GameFIG_RY.instance.PlayMusic(0);
                // 用户点击了【关闭广告】按钮
                if (GameFIG_RY.instance.success_HanderUse) {
                    GameFIG_RY.instance.success_HanderUse.run();
                    GameFIG_RY.instance.success_HanderUse = undefined;
                    GameFIG_RY.instance.fail_HanderUse = undefined;
                }
                GameFIG_RY.instance.TiShiKuang("已获得观影奖励");
                GameFIG_RY.instance.redio.load();

            })
            GameFIG_RY.instance.redio.load();
        }


    }
    initGG() { //重写
        if (this.wx) {
            this.JtGG();
            this.dtgg();
        }
    }
    GetGameInitConfig() { //重写

    }
    /**
    * 打开广告_分享汇总方法 vivo分享修改为百分百获取有修改需求自定义
    * @param {*bool} AotoSPFX  true视频 false分享 0 随机
    * @param {*Laya.Handler} success_Hander 成功分享/观看视频时调用
    * @param {*Laya.Handler}fail_Hander 失败分享/观看视频时调用
    */
    GG_all(AotoSPFX = 0, success_Hander, fail_Hander) {

        if (success_Hander) {
            this.success_HanderUse = success_Hander;

        }
        if (fail_Hander) {
            this.fail_HanderUse = fail_Hander;
        }
        if (this.wx) {
            if (AotoSPFX == 0) {
                this.TVorShare = !this.TVorShare;
            } else {
                this.TVorShare = AotoSPFX;
            }
            if (this.TVorShare) { //视频

                if (this.readtf && this.redio) {
                    Laya.SoundManager.muted = true;
                    this.redio.offShow();
                    this.redio.onShow((res) => {
                  
                    })
                    this.redio.show();
                } else {
                    GameFIG_RY.instance.TiShiKuang("暂无广告");
                    GameFIG_RY.instance.redio.load();

                }

            } else { //分享
                this.FXget();

            }
        } else {

            if (success_Hander) {
                success_Hander.run();

            }
        }


    }

    /**
     * * 主动分享
     * @param {*} successhander成功
     * @param {*} failhander 

     */
    FXget() { //分享
        if (this.wx) {
            if (this.wx.getSystemInfoSync().platformVersionCode >= 1080) {
                this.wx.share({
                    success: (res) => {
                        console.log("分享成功");
                        if (GameFIG_RY.instance.success_HanderUse) {
                            GameFIG_RY.instance.success_HanderUse.run();
                            GameFIG_RY.instance.success_HanderUse = undefined;
                        }
                        GameFIG_RY.instance.TiShiKuang("已获得分享奖励");
                    },
                    fail: () => {
                        GameFIG_RY.instance.TiShiKuang("分享失败");
                        if (GameFIG_RY.instance.fail_HanderUse) {
                            GameFIG_RY.instance.fail_HanderUse.run();
                            GameFIG_RY.instance.fail_HanderUse = undefined;
                        }
                    },
                    camcel: () => {
                        GameFIG_RY.instance.TiShiKuang("已取消分享");
                        if (GameFIG_RY.instance.fail_HanderUse) {
                            GameFIG_RY.instance.fail_HanderUse.run();
                            GameFIG_RY.instance.fail_HanderUse = undefined;
                        }
                    }
                });
            }
        }

    }

    /**
     * 
     * @param {*} biaoti 标题
     * @param {*} msg 内容
     * @param {Laya.Handler} success_Hander 成功回调 
     * @param {Laya.Handler} cancel_Hander 失败/取消 回调
     */
    JiaoHukuang(biaoti, msg, success_Hander, cancel_Hander) {
        if (GameFIG_RY.instance.wx) {
            GameFIG_RY.instance.wx.showModal({
                title: biaoti,
                content: msg,
                showCancel: true,
                cancelText: "取消",
                confirmText: "确定",
                success: (res) => {
                    if (res.confirm) {
                        if (success_Hander) {
                            success_Hander.run();
                        }
                    } else {
                        if (cancel_Hander) {
                            cancel_Hander.run();
                        }
                    }

                },

            })
        } else {
            if (success_Hander) {
                success_Hander.run();
            }
        }
    }
    /**
         * vivo自带提示框
         * @param {String} msg 提示信息 
         * @param {Number} duration 显示的时长 默认200 短时间 超过就是长时间 已自适应微信版本
         */
    TiShiKuang(msg, duration = 200) {
        if (GameFIG_RY.instance.wx != undefined) {
            GameFIG_RY.instance.wx.showToast({
                message: msg,
                duration: duration > 200 ? 1 : 0
            })
        } else {
            alert(msg);
        }

    }

    /**
          * 播放音效2 单人播放(网络加载模式) 仅会存在一个音源，播放新的会关闭之前未播放完的音效
          * @param {String} url 地址
          * @param {Number} isloop 是否循环 默认1次  0表示无限循环
          * @param {Boolean} tfShort 是否是短音频 
          * @param { Laya.Handler} OkHander 加载完成回调 参数返回音频长度 一般在微信都不灵这个长度
          * @param { Laya.Handler} overHander 播放结束回调
          */
    PlaySound2(url, isloop = 1, tfShort = true, OkHander = new Laya.Handler(), overHander = new Laya.Handler()) {

        // if (GameFIG_RY.instance.wx) {//微信状态
        //     if (this.Open.YX) {
        //         if (this.innerAudioContext) {
        //             this.innerAudioContext.stop();
        //             this.innerAudioContext.destroy()
        //         } else {
        //             this.innerAudioContext = GameFIG_RY.instance.wx.createInnerAudioContext()
        //         }

        //         this.innerAudioContext.src = url
        //         this.innerAudioContext.play();
        //         this.innerAudioContext.onPlay(() => {
        //             console.log('开始播放')
        //             OkHander.runWith(this.innerAudioContext.duration);

        //         })
        //         this.innerAudioContext.onEnded(() => {
        //             console.log('播放结束')
        //             overHander.run();
        //             // this.innerAudioContext.destroy();
        //         })

        //     }
        // } else {


        // }
        if (this.Open.YX) {//网络预加载音效保持和文字同步进行
            OkHander.run();
            if (this.PlaySound2_Sound != undefined) {
                this.PlaySound2_Sound.stop();
                Laya.SoundManager.removeChannel(this.PlaySound2_Sound);
            }
            if (!tfShort) {
                Laya.timer.once(100, this, function (params) {
                    this.PlaySound2_Sound = Laya.SoundManager.playSound(url, isloop, overHander);
                })
            } else {
                this.PlaySound2_Sound = Laya.SoundManager.playSound(url, isloop, overHander);
            }
        }
    }
    /**判断是否可以打开广告 */
    TFOpenGG(id = "all") {
        if (!this.TFOpenGame[id]) {
            var timeGo = new Date(GameFIG_Config.GameGGConfig.Vivo.openDay.time[id]).getTime();
            var timeNow = new Date().getTime();
            var Cha = (timeNow - timeGo) / 1000;
            var TFopen = Cha >= GameFIG_Config.GameGGConfig.Vivo.openDay.WiteDay * 60 * 60 * 24;//
            this.TFOpenGame[id] = TFopen ? "AA" : "BB";
        }
        return this.TFOpenGame[id] == "AA";
    }

    /**
     * vivo 文件写入本地储存
     * @param {string} uri 路径 ：image/aa.png;
     * @param {*} text string/ArrayBuffer 储存数据utf8格式
     * @param {Laya.Handler} OkHander 成功回调
     * @param {Laya.Handler} failHander 失败回调
     */
    WriteFile(uri = "", text, OkHander = new Laya.Handler(), failHander = new Laya.Handler()) {
        if (this.wx) {
            try {
                this.wx.writeFile({
                    filePath: 'internal://files/' + uri,
                    data: text,
                    append: true,//是否覆盖旧文件
                    success: function (uri) {
                        console.log(`handling success: ${uri}`)
                        OkHander.run();
                    },
                    fail: function (data, code) {
                        failHander.run();
                    }
                })
            } catch {
                try {
                    const result = this.wx.writeFileSync({
                        filePath: 'internal://files/' + uri,
                        tdataxt: text,
                        append: true
                    })

                    if (result) {
                        OkHander.run();
                    }
                    else {
                        failHander.run();
                    }
                } catch {
                    failHander.run();
                }

            }


        } else {
            failHander.run();
        }

    }
    /**
     * vivo 本地文件读取
     * @param {string} uri 路径：image/aa.png;
     * @param {Laya.Handler} OkHander 成功回调
     * @param {Laya.Handler} failHander 失败回调
     */
    ReadFile(uri = "", OkHander = new Laya.Handler(), failHander = new Laya.Handler()) {
        if (this.wx) {
            try {
                this.wx.readFile({
                    filePath: 'internal://files/' + uri,
                    encoding: 'utf8',
                    success: function (data) {
                        OkHander.runWith(data.text);
                    },
                    fail: function (data, code) {
                        failHander.run();
                    }
                })
            } catch {
                try {
                    const result = this.wx.readFileSync({
                        filePath: 'internal://files/' + uri,
                        encoding: 'utf8',
                    })

                    if (typeof result === 'string') {
                        failHander.run();
                    }
                    else {
                        OkHander.runWith(data.text);
                    }
                } catch {
                    failHander.run();
                }

            }

        } else {
            failHander.run();
        }
    }

}
