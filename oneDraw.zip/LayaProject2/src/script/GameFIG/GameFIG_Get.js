

import GameFIG_WX from "./GameFIG_WX";


/**游戏工具类_Vivo */
export default class GameFIG_Get {
    constructor() { //请务必设置这里面的参数

    }
    /**
      *  Get 单例获取工具类
      * @return {GameFIG_App} 
      */
    static Get() {
        if (GameFIG_Get.instance == undefined) {
            GameFIG_Get.instance = new GameFIG_WX();
        }
        return GameFIG_Get.instance;
    }


}
