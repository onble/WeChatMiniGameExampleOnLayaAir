declare module "*GameFIG_WX.js" {
    export default class GameFIG_WX {
        static Get(): GameFIG_WX
        wx: any
        Open: {
            [key: string]: boolean,
            YX: boolean,
            ZD: boolean,
            MC: boolean
        }
        Main_Use(LoginHander: Laya.Handler): void;
        /**
          * 导出信息至本地——json
          * @param {*} MSG 数据json格式
          *  @param {*} Faliname 导出文件名 
          */
        SaveMsgToJson(MSG: any, Faliname: string): void
        /**banner展示 */
        bannershow(): void
        /**隐藏banner */
        hidebanner(): void
        /**开启视频广告 */
        GG_all(AotoSPFX: number | boolean, success_Hander?: Laya.Handler, fail_Hander?: Laya.Handler): void
        /**主动调用分享 */
        FXget(): void
        /**
         * 更新玩家数据
         * @param ttff 是否保存到服务器
         */
        UpdatePlayerMsg(ttff: boolean = false): void
        /**
         * 设置图片颜色
         * @param but 按钮
         * @param color 颜色#FFFFF
         */
        SetColorToBut(but: Laya.Image, color: string): void
        /**
         * 按钮动画汇总
         * @param  but  按钮
         * @param  FunHander  点击按钮后的回调
         * @param  keyMusicID   播放音效传入音效表ID  
         * @param  TFScaleAuto 是否不进行缩放模拟
         * @param  color 触发颜色 触发改变按钮颜色 抬起恢复 #000000
         */
        butTween(but: Laya.Node, FunHander: Laya.Handler, keyMusicID?: number, TFScaleAuto?: boolean, color?: string): void
        /**
          * 播放音乐 (网络加载模式)
          * @param {*} id 音乐表ID
          */
        PlayMusic(id: number): void
        PlayMusic2(url: string, once: number): void
        PauseMusic(): void
        ResumeMusic(): void
        StopMusic(): void
        /**
         * 播放音效
         * @param id 音乐表ID
         * @param isloop 是否循环 默认1次  0表示无限循环
         */
        PlaySound(id: number, isloop: number = 1): void
        /**微信震动 */
        wxZD(): void
        /**
         * 提示框
         * @param msg 提示信息
         * @param time 显示的时间  默认2000毫秒
         * @param TFMask 是否开启按钮mask 防止点击穿透 默认false
         */
        TiShiKuang(msg: string, time: number = 2000, TFMask: boolean = false): void
        /**
         * 交互框
         * @param biaoti 标题
         * @param msg 内容
         * @param success_Hander 成功回调
         * @param cancel_Hander 失败/取消 回调
         */
        JiaoHukuang(biaoti: string, msg: string, success_Hander: Laya.Handler, cancel_Hander: Laya.Handler)
        /**
         * 获取随机正整数
         * @param min 最小值 包含
         * @param max 最大值 包含
         */
        GetRandNub(min: number, max: number): number
        /**
        * 获取min~max的整数 例如-50~50
        * @param {*} min 最小数整数
        * @param {*} max 最大数正整数
        */
        GetRandNub2(min: Number, max: number): number
        /**
         * 初始化页面跳转
         * @param array 页面数组 例如：[this.zjm_ceng,this.load_Ceng]
         * @param back 页面调整背景 this.backback
         */
        InitViewToView(array: any, back?: any): void
        /**
         * 打开页面 使用前请调用**InitViewToView**
         * @param whereid 从何id
         * @param toid 去哪儿id
         * @param isclose 是否关闭当前页面
         * @param openOrCloseBcke 关闭或者开启遮罩
         * @param OverHander 完成回调
         */
        ViewToView(whereid: number, toid: number, isclose: boolean = true, openOrCloseBcke: boolean = false, OverHander?: Laya.Handler)
        /**
         * 游戏跳转
         * @param oppid 游戏的appid
         * @param OverFun 回调
         */
        GoToGame(oppid: string = "", OverFun: Laya.Handler): void
        /**
         * 微信加载提示
         * @param {String} msg 提示文字
         * @param {Boolean} mask 是否开启遮罩，防止点击穿透
         */
        WxShowLoading(msg: string, mask?: boolean): void;

        WxHideLoading(): void
        /**
         *  返回一个bool
         * @param {*} D1 第一日期 Date类型
         * @param {*} D2 第二日期 Date类型
         */
        TFdate(D1: Date, D2: Date): boolean
        /**
          * 本地储存数据
          * @param key 对应的 key 值
          * @param data 对应的数据
          */
        saveLocalData(key: string, data: any): void;
        /**
        * 获取本地数据
        * @param key 对应的 key 值
        */
        fetchLocalData<T>(key: string): T;
        /**随机打乱数组 */
        Randshuzhu<T>(array: T[]): T[];
    }
}
declare module "*GameFIG_App_JSBridge.js" {
    export class GameFIG_App_JSBridge {
        /**初始化 */
        InitJsBridge(): void;
        /**播放视频*/
        playVideo(videoUrl: string): void;
        /**暂停视频*/
        pauseVideo(): void;
        /**继续播放视频*/
        resumeVideo(): void;
        /**显示视频窗口 */
        showVideoWindow(): void;
        /**隐藏视频窗口 */
        hideVideoWindow(): void;
        /**视频缓冲回调 res 0-1*/
        onVideoOnLoading(res: number): void;
        /**视频播放完成回调 */
        onVideoPlayEnd(): void;
        /**视频错误回调*/
        onVideoError(err: string): void;
        /**获取录音地址回调 */
        onGetRecord(path: string): void;
        /**开始录音 PathName 地址文件名 例如 Unit1-1.mp3*/
        BeginRecord(PathName: string): void;
        /**结束录音 */
        stopRecording(): void;
        /**开始录音回调 */
        OnBeginRecord(): void;
        /**录音错误回调 */
        OnRecordErr(err: string): void;
        /**播放音频失败 */
        OnAudioErr(err: string): void;
        /**播放音频完成 */
        OnAudioOver(): void;
        /**
         * 查询文件是否存在
         * @param {*} path 文件路径 需要完整路径例如 /data/data/com.example.demo/files/Unit1-1.mp3
         */
        isFileHas(path: string): boolean
        /**
         * 原生okhttp 访问
         * @param serverUrl 完整接口地址
         * @param token token 不需要不传
         * @param jsonData body 不需要不传 {}结构
         */
        OkHttp(serverUrl: string, token?: string, jsonData?: any)
        /**服务器监听异常 */
        OnOkHttpErr(err: string): void;
        /**服务器回调 */
        onOkHttpBack(data: string): void;
        /**获取剪切板内容 */
        CopyClip(): void;
        /**剪切板回调 */
        onCopyClipBack(str: string): void;
    }
}
declare module "*GameFIG_App.js" {
    import GameFIG_WX from "*GameFIG_WX.js";
    import { GameFIG_App_JSBridge } from ".*GameFIG_App_JSBridge";
    export default class GameFIG_App extends GameFIG_WX {
        JSBridge: GameFIG_App_JSBridge
        Main_Use(LoginHander?: Laya.Handler, InitHander?: Laya.Handler): void;
        static Get(): GameFIG_App
        /**
         * 播放音效 Url方式
         * @param url 
         * @param isloop 1次 0无限
         * @param isOne  是否是唯一 true 会关闭其他音效
         */
        PlaySound2(url: string, isloop?: number, isOne?: boolean, OkHander?: Laya.Handler, overHander?: Laya.Handler): void
        /**在App原生端播放音效 地址是原生端地址 其他laya地址网络地址 请用 PlaySound2*/
        PlaySoundApp(url: string, overHander?: Laya.Handler): void;
        /**停止原生音效 */
        StopSoundApp(): void;
        /**初始化 全局加载Loading */
        InitShowLoading(Prefab: Laya.Prefab): Laya.Sprite;
        /**初始化 全局提示框 */
        initTishi(Prefab: Laya.Prefab): Laya.Sprite;
        /**初始化 其他设备登录回调监听 */
        InitOnTherAC(OverHander: Laya.Handler): void
        /**
         * 获取验证码
         * @param Iphone  手机号
         * @param success 
         * @param fail 
         */
        GetSMS(Iphone: string, success: Laya.Handler, fail: Laya.Handler): void
        /**
         * 登录
         * @param account 账号
         * @param code 验证码
         * @param success 
         * @param fail 
         */
        Login(account: string, code: string, success: Laya.Handler, fail: Laya.Handler): void
        /**
        * 上传文件
        * @param {*} FilePath 文件地址 请附带后缀的完整地址 例如：file:///storage/emulated/0/Android/data/com.example.game/files/text.mp3
        * @param {*} success
        * @param {*} fail
        */
        UpFile(FilePath: string, success: Laya.Handler, fail: Laya.Handler): void

        /**
        * 语音对比接口
        * @param {*} fileId web端上传文件返回的fileId
        * @param {*} word 语音对比的单词或句子
        * @param {*} tp 0单词 1是句子 2段落 3自由说 4单词音素纠错 ==== 具体请了解 腾讯云 智聆口语评测接口文档
        * @param {*} success
        * @param {*} fail
        */
        ToVVS(fileId: string, word: string, tp: string, success: Laya.Handler, fail: Laya.Handler): void
        /**
         * 
         * @param {String} name 名字
         * @param {String} text  文本
         * @param {Laya.Handler} OkHander 成功回调
         * @param {string} speakerId 腾讯云语音合成角色ID 101015 男孩 101016女孩(默认)
         */
        Getvoice(name: string, text: string, OkHander = new Laya.Handler(), speakerId?: string): void
        /**
         * 获取用户信息接口
         * @param success 
         * @param fail 
         */
        getplayer(success: Laya.Handler, fail: Laya.Handler): void

        /**
      * 提交反馈
      * @param txt 内容
      * @param tile 标题
      * @param complete 回调 附带 true false 表示成功失败
      */
        ToFanKui(txt: string, tile: string, complete: Laya.Handler): void

        /**
       * 查询我发布的作业
       * @param {*} complete 
       */
        GetWorkMe(complete: Laya.Handler): void
        /**
         * 查询我管理的班级情况
         * @param {*} complete 
         */
        GetMyClass(complete: Laya.Handler): void
        /**
         * 布置作业
         * @param content 作业标识 Leve1_1
         * @param complete 
         */
        PutMyWork(content = string, class_id: string, complete: Laya.Handler): void
        /**
         * 查询学生提交的作业情况
         * @param question_id 作业id
         * @param complete 
         */
        GetStuWork(question_id = string, complete: Laya.Handler): void

        /**
         * 审批学生作业
         * @param answer_id 回答id
         * @param review_content 审批内容
         * @param complete 
         */
        SetStuWork(answer_id = string, review_content: string, complete: Laya.Handler): void

        /**
       * 查询自己提交的作业
       * @param complete 
       */
        GetStuDoWork(complete: Laya.Handler): void
        /**
         * 提交作业
         * @param file 录音地址集
         * @param question_id 作业id
         * @param complete 
         */
        PutStuDoWork(file: string[], question_id: string, complete: Laya.Handler): void
        /**
         * 获取排行榜
         * @param question_id 作业id
         * @param complete 
         */
        GetRank(question_id: string, complete: Laya.Handler): void

        /**
        * 获取粘贴板
        * @param {*} OverHander  
        */
        GetCopyClip(OverHander: Laya.Handler): void
    }
}
declare module "*GameFIG_YaoGan.js" {
    export class GameFIG_YaoGan {
        MoveRot: number = 0;
        MovePOS: { x: number, y: number };
        DownFun: Function = null;
        MoveFun: Function = null;
        HuaGan_Fun2: Function = null;
        /**开启后 不会随摇杆距离控制速度 各个方向速度一致  */
        static isDefMax: boolean = false;
        static Get(): GameFIG_YaoGan
        /**
          * 初始化摇杆：注意设置规范(整局只用初始化一次即可，除非后续变更参数)
          * @param {Number} Movespeed 移动速度
          * @param {Number} MoveJULIbiaoz 摇杆的可移动范围半径 从圆心可以移动到边缘的最大距离 按像素
          * @param {Boolean} TFHide 是否自动隐藏摇杆
          * @param {Laya.Sprite} bigCircle 大圆圈 **（必填）**
          * @param {Laya.Sprite} smallCircle 小圆圈 **（必填）**
          * @param {Laya.Sprite} move_ceng 摇杆移动层(摇杆在什么上面移动 超出则不移动 通常左半屏摇杆 右半屏其他按钮) （可选）
          * @param {Function} MoveFun 摇杆移动回调 返回两个参数 位置和 角度
          * @param {Function} Fun2 松开摇杆 调用方法 （可选）     
          * @param {Function} DownFun 首次按下摇杆 调用方法（可选）
          * @param {Laya.Sprite} YaoGanRoat 摇杆指针 （可选）
          * @param {Boolean} TF_EvenOver 是否 监听move_uo_out事件时候 将move_ceng 切换到顶部 防止其他UI挡住事件监听  默认true
          * @param 其他关联方法 OpenYaoGan(开启摇杆) CloseYaoGan(关闭摇杆)
          */
        InitYaoGan(Movespeed: number = 1, MoveJULIbiaoz: number = 100, TFHide: boolean = false, bigCircle: Laya.Sprite = null, smallCircle: Laya.Sprite = null, move_ceng?: Laya.Sprite = Laya.stage, MoveFun?: Function, Fun2?: Function, DownFun?: Function, YaoGanRoat?: Laya.Sprite, TF_EvenOver?: boolean = true): void
        /**开启角色摇杆*/
        OpenYaoGan(): void
        /**关闭角色摇杆*/
        CloseYaoGan(): void
    }
}
declare module "*GameFIG_Config.js" {
    export class GameFIG_Config {
        /**后台固定头像集 */
        static HeadUrls: string[]
        /**游戏配置 */
        static GameConfig: {
            banbenID: string,
            GameName: string,
            InitFBL: { width: number, height: number, isHoS: boolean },
            otherSet: {

            },

        }
        /**玩家本地数据 */
        static player_Config: {
            [key:string]:any,
            Name: string,
            HeadUrl: string,
            FirstTime: string,
            openid: string,
            lastTime: string,
            Sgin: string,
            DoNotSQ: boolean,
            YS: number,// 钥匙
            TS: number,// 提示
            GK: number[],//关卡剩余解锁数量
            GKLeve: number[],//需要多少钥匙解锁
            QD: { day: number, LastDay: any },//签到
        }

        static MusicJson: { name: string, URL: string }[];
    }
}
declare module "*Cocos_Api_MG.js" {
    export class Cocos_Api_MG {
        /**
    * 判断三点是否共线 /判断q点是否在P1 P2之间 尽量整数
    * @param {*} Pi {x:0,y:0} 
    * @param {*} Pj {x:0,y:0} 
    * @param {*} Q {x:0,y:0} 
    */
        static onSegment(Pi: any, Pj: any, Q: any): boolean;
        /**数组hash去重 */
        static uniArray<T>(arr: T[]): T[];
        /**
         * 逐元素向量减法
         * @param point1 {x,y}
         * @param point2 {x,y}
         */
        static subtract(point1: any, point2: any): { x: number, y: number }
        /**
         * 向量长度平方
         * @param a {x,y}
         */
        static lengthSqr(a: any): number
        /**
         * 秒 转换 00:00 格式
         * @param m 
         */
        static MtoAABB(m: number): string
        /**
         * 向量点积
         * @param point1 {x,y}
         * @param point2 {x,y}
         */
        static dot(point1: any, point2: any): number
        /**
       * 通过三个点创建贝塞尔曲线
       * @param p0 起点
       * @param p1 终点
       * @param heightRatio 高度比例
       * @param xRatio x 比例
       * @param t 进度 0-1
       * @returns {x, y} 曲线上的点
       */
        static createBezierCurveByHeightAndXRatios(p0: any | { x: number, y: number }, p1: any | { x: number, y: number }, heightRatio: number, xRatio: number, t: number): { x: number, y: number }
        /**
         * 贝塞尔 抛物线
         * @param p0 起点
         * @param p2 终点
         * @param height 高度
         * @param t 进度0-1
         */
        static bezier(p3: Laya.Vector2 | any, p2_2: Laya.Vector2 | any, height: number, t: number): Laya.Vector2 | any;
        /**
         * 获取目标物体对应当前物体的距离
         * @param {*} start {x:当前物体x,y：当前物体y}
         * @param {*} end  {x:目标物体x，y:目标物体y}
         */
        static GetDistanceByTwoNode(start: Laya.Vector2 | any, end: Laya.Vector2 | any): number
        /**
        * 矩形碰撞检测 是否碰撞
        * @param {*} objA 对象A 包含(x, y, width, height)
        * @param {*} objB 对象B 包含(x, y, width, height)
        * @returns { * } TF是否碰撞 BFB交集面积百分比(A有多少部分相交于B 保留两位小数);
         */
        static Collision(objA: any, objB): { TF: boolean, BFB: number }

        /**
           * 获取目标物体对应当前物体的角度值
           * @param {*} start {x:当前物体x,y：当前物体y}
           * @param {*} end  {x:目标物体x，y:目标物体y}
           */
        static GetRotationByTwoNode(start, end): number

        /**
           * 毫秒转换为 2022-12-11 11:11 格式
           * @param {*} timestamp 
           * @returns 
           */
        static formatDate(timestamp: number): string
    }
}
declare module "*GameFIG_Get.js" {

    import GameFIG_App from "*GameFIG_App.js";
    export default class GameFIG_Get {
        static Get(): GameFIG_App
    }
}
declare module "*MGG_Show.js" {
    export default class MGG_Show {
        static Get(): MGG_Show
        InitJson(SuccessHandler: Laya.Handler): void;
        InitMGG_ShowTemplet(SuccessHandler: Laya.Handler): void;
        /**
         * 
         * @param Node Node 加入到那个节点默认Laya.stage
         */
        MShow(Node: Laya.stage): Laya.Skeleton;
        /**
         *  萌果整体切换皮肤
         * @param {*} skShow 萌果实体节点
         * @param {*} PFconfig 换装配置参数 参考 this.NowPFB 
         */
        MShow_ChangeAll(skShow: any, PFconfig: any)
        /**
            * 萌果单独切换皮肤
            * @param {*} skShow 萌果实体节点
            * @param {*} js   Hear,Fashi,Yifu,Kuzhi,Wazhi
            * @param {*} ID  对应MGGShow_Buy的下标第几套
            */
        MShow_ChangeOnly(skShow: any, js: any, ID: number): void
        /**同步所有MGG服装*/
        UpdateAllMgg(): void
        /**
            * 当前服装配置参数 示范
            * @param {*特殊} SID为-1则不佩戴当前物体 仅部分支持 目前裤子衣服不支持:不显示太露了
            */
        NowPFB: { Hear: number, Fashi: number, Yifu: number, Kuzhi: number, Wazhi: number };
        AllMGGShow: any;
    }
}
