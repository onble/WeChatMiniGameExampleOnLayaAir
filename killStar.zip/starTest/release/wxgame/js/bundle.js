(function () {
    'use strict';

    var View = Laya.View;
    var REG = Laya.ClassUtils.regClass;
    var ui;
    (function (ui) {
        var test;
        (function (test) {
            class TestSceneUI extends View {
                constructor() { super(); }
                createChildren() {
                    super.createChildren();
                    this.loadScene("test/TestScene");
                }
            }
            test.TestSceneUI = TestSceneUI;
            REG("ui.test.TestSceneUI", TestSceneUI);
        })(test = ui.test || (ui.test = {}));
    })(ui || (ui = {}));

    class GameUI extends ui.test.TestSceneUI {
        constructor() {
            super();
        }
        onAwake() {
        }
    }

    let com = {
        isGameOver: false,
        score: 0,
    };

    class OverCtr extends Laya.Script {
        constructor() {
            super();
            OverCtr.instance = this;
        }
        onAwake() {
            this.overPanel = this.owner;
            this.back_bt = this.overPanel.getChildByName("back_bt");
            this.score = this.overPanel.getChildByName("score");
        }
        onStart() {
            this.back_bt.on(Laya.Event.CLICK, this, () => {
                this.showUIName(false);
                StartPanelCtr.instance.showUIName(true);
            });
        }
        showUIName(isShow) {
            this.overPanel.visible = isShow;
            if (isShow) {
                this.score.text = "" + com.score;
                StarCreate.instance.showGameUI(false);
            }
        }
    }
    OverCtr.instance = null;

    class starControl extends Laya.Script {
        constructor() {
            super();
            this.index_x = 0;
            this.index_y = 0;
        }
        onAwake() {
            this.star = this.owner;
            this.onClick();
        }
        onClick() {
            this.star.on(Laya.Event.MOUSE_DOWN, this, this.clcikCallBack);
        }
        offClick() {
            this.star.off(Laya.Event.MOUSE_DOWN, this, this.clcikCallBack);
        }
        clcikCallBack() {
            if (com.isGameOver)
                return;
            console.log("1111");
            StarCreate.instance.clickStar(this.index_x, this.index_y);
        }
    }

    class StarCreate extends Laya.Script {
        constructor() {
            super();
            this.startPos = new Laya.Vector2(90, 90);
            this.starsSkin = ["star/0.png", "star/1.png", "star/2.png", "star/3.png", "star/4.png"];
            this.interval = 75;
            this.create_stars = [];
            this.arr_maps = [];
            this.arr_stars = [];
            this.h_starnums = 7;
            this.v_starnums = 11;
            StarCreate.instance = this;
        }
        onAwake() {
            this.gamePanel = this.owner;
            this.stars = this.gamePanel.getChildByName("bg").getChildByName("stars");
            this.score = this.gamePanel.getChildByName("score");
        }
        onStart() {
        }
        showGameScore() {
            this.score.text = "" + com.score;
        }
        showGameUI(isShow) {
            this.gamePanel.visible = isShow;
            if (isShow) {
                this.randMap();
                this.showGameScore();
            }
            else {
                this.clearStar();
            }
        }
        clearStar() {
            for (let i = 0; i < this.h_starnums; i++) {
                for (let j = 0; j < this.v_starnums; j++) {
                    if (this.arr_stars[i][j] != null) {
                        this.recoveryStar(this.arr_stars[i][j]);
                    }
                }
            }
            this.arr_stars = [];
            this.arr_maps = [];
            com.isGameOver = false;
            com.score = 0;
            this.showGameScore();
        }
        randMap() {
            console.log("创建");
            for (let i = 0; i < this.h_starnums; i++) {
                let arr1 = [];
                let arr2 = [];
                this.arr_stars.push(arr1);
                this.arr_maps.push(arr2);
                for (let j = 0; j < this.v_starnums; j++) {
                    let rand = Math.floor(Math.random() * 5) + 1;
                    let star = null;
                    this.arr_maps[i].push(rand);
                    this.arr_stars[i].push(star);
                }
            }
            this.createMap();
        }
        createStar(num, pos) {
            let star = null;
            if (this.create_stars.length > 0) {
                star = this.create_stars.pop();
            }
            else {
                star = new Laya.Image(this.starsSkin[num]);
                star.width = 70;
                star.height = 70;
                star.anchorX = 0.5;
                star.anchorY = 0.5;
                star.addComponent(starControl);
            }
            this.stars.addChild(star);
            star.x = pos.x;
            star.y = pos.y;
            return star;
        }
        recoveryStar(obj) {
            if (obj.parent) {
                obj.destroy();
            }
        }
        createMap() {
            for (let i = 0; i < this.h_starnums; i++) {
                for (let j = 0; j < this.v_starnums; j++) {
                    if (this.arr_maps[i][j] != 0) {
                        let star = this.createStar(this.arr_maps[i][j] - 1, new Laya.Vector2(this.startPos.x + this.interval * i, this.startPos.y + this.interval * j));
                        this.arr_stars[i][j] = star;
                        star.getComponent(starControl).index_x = i;
                        star.getComponent(starControl).index_y = j;
                    }
                }
            }
        }
        clickStar(index_x, index_y) {
            let arr = [];
            let V_arr = [];
            this.getIdenticalStar(index_x, index_y, arr);
            if (arr.length != 0) {
                for (let i = 0; i < arr.length; i++) {
                    this.recoveryStar(this.arr_stars[arr[i].x][arr[i].y]);
                    this.arr_stars[arr[i].x][arr[i].y] = null;
                    this.arr_maps[arr[i].x][arr[i].y] = 0;
                    if (!this.isInArr(V_arr, arr[i].x)) {
                        V_arr.push(arr[i].x);
                    }
                }
                for (let i = 0; i < V_arr.length; i++) {
                    this.V_Sort(V_arr[i]);
                }
                for (let i = 0; i < V_arr.length; i++) {
                    this.H_Sort(V_arr[i]);
                }
                if (this.IsOver()) {
                    console.log("游戏结束");
                    com.isGameOver = true;
                    OverCtr.instance.showUIName(true);
                }
                if (arr.length <= 2) {
                    com.score += 10 * arr.length;
                }
                else if (arr.length <= 4) {
                    com.score += 20 * arr.length;
                }
                else {
                    com.score += 35 * arr.length;
                }
                this.showGameScore();
            }
            ;
        }
        V_Sort(num) {
            let down = 0;
            for (let i = this.v_starnums - 1; i >= 0; i--) {
                let ishave = false;
                if (this.arr_maps[num][i] == 0) {
                    for (let j = i - 1; j >= 0; j--) {
                        if (this.arr_maps[num][j] != 0) {
                            ishave = true;
                            this.arr_stars[num][j].getComponent(starControl).index_y += 1;
                            Laya.Tween.to(this.arr_stars[num][j], { y: this.startPos.y + this.interval * this.arr_stars[num][j].getComponent(starControl).index_y }, 100, null);
                        }
                    }
                    if (ishave) {
                        down++;
                    }
                }
            }
            if (down != 0) {
                for (let i = this.v_starnums - 1; i >= 0; i--) {
                    if (this.arr_maps[num][i] != 0) {
                        let starnum = this.arr_maps[num][i];
                        this.arr_maps[num][i] = 0;
                        let star = this.arr_stars[num][i];
                        this.arr_stars[num][i] = null;
                        let control = star.getComponent(starControl);
                        this.arr_maps[control.index_x][control.index_y] = starnum;
                        this.arr_stars[control.index_x][control.index_y] = star;
                    }
                }
            }
        }
        H_Sort(num) {
            if (this.isV_Star(num)) {
                return;
            }
            else {
                let isMove = false;
                for (let i = num; i < this.h_starnums; i++) {
                    for (let j = 0; j < this.v_starnums; j++) {
                        if (this.arr_stars[i][j] != null) {
                            let star = this.arr_stars[i][j];
                            let control = star.getComponent(starControl);
                            control.index_x -= 1;
                            Laya.Tween.to(star, { x: this.startPos.x + this.interval * control.index_x }, 100, null);
                            isMove = true;
                        }
                    }
                }
                if (isMove) {
                    for (let i = num; i < this.h_starnums; i++) {
                        for (let j = 0; j < this.v_starnums; j++) {
                            if (this.arr_stars[i][j] != null) {
                                let star = this.arr_stars[i][j];
                                let starnum = this.arr_maps[i][j];
                                this.arr_stars[i][j] = null;
                                this.arr_maps[i][j] = 0;
                                let control = star.getComponent(starControl);
                                this.arr_maps[control.index_x][control.index_y] = starnum;
                                this.arr_stars[control.index_x][control.index_y] = star;
                            }
                        }
                    }
                }
            }
        }
        getIdenticalStar(index_x, index_y, arr) {
            let starnum = this.arr_maps[index_x][index_y];
            for (let i = -1; i <= 1; i++) {
                for (let j = -1; j <= 1; j++) {
                    if (Math.abs(i + j) == 1) {
                        if (this.isLimit(index_x + i, index_y + j)) {
                            if (this.arr_maps[index_x + i][index_y + j] == starnum) {
                                if (this.isInAarry(arr, { x: index_x + i, y: index_y + j }) == false) {
                                    arr.push({ x: index_x + i, y: index_y + j });
                                    this.getIdenticalStar(index_x + i, index_y + j, arr);
                                }
                            }
                        }
                    }
                }
            }
        }
        isV_Star(num) {
            let ishaveStar = false;
            for (let i = 0; i < this.v_starnums; i++) {
                if (this.arr_stars[num][i] != null) {
                    ishaveStar = true;
                }
            }
            return ishaveStar;
        }
        IsSameStar(index_x, index_y) {
            let starnum = this.arr_maps[index_x][index_y];
            let ishave = false;
            for (let i = -1; i <= 1; i++) {
                for (let j = -1; j <= 1; j++) {
                    if (Math.abs(i + j) == 1) {
                        if (this.isLimit(index_x + i, index_y + j)) {
                            if (this.arr_maps[index_x + i][index_y + j] == starnum) {
                                ishave = true;
                                break;
                            }
                        }
                    }
                }
                if (ishave == true) {
                    break;
                }
            }
            return ishave;
        }
        isLimit(index_x, index_y) {
            if (index_x >= 0 && index_x < this.h_starnums && index_y >= 0 && index_y < this.v_starnums) {
                return true;
            }
            else {
                return false;
            }
        }
        isInAarry(arr, obj) {
            let isIn = false;
            for (let i = 0; i < arr.length; i++) {
                if (arr[i].x == obj.x && arr[i].y == obj.y) {
                    isIn = true;
                    break;
                }
            }
            return isIn;
        }
        isInArr(arr, num) {
            let isIn = false;
            for (let i = 0; i < arr.length; i++) {
                if (arr[i] == num) {
                    isIn = true;
                    break;
                }
            }
            return isIn;
        }
        IsOver() {
            let isover = true;
            for (let i = 0; i < this.h_starnums; i++) {
                for (let j = this.v_starnums - 1; j >= 0; j--) {
                    if (this.arr_maps[i][j] != 0) {
                        if (this.IsSameStar(i, j) == true) {
                            isover = false;
                            break;
                        }
                    }
                }
                if (!isover) {
                    break;
                }
            }
            return isover;
        }
    }
    StarCreate.instance = null;

    class StartPanelCtr extends Laya.Script {
        constructor() {
            super();
            StartPanelCtr.instance = this;
        }
        onAwake() {
            this.startPanel = this.owner;
            this.start_bt = this.startPanel.getChildByName("start_bt");
        }
        onStart() {
            this.start_bt.on(Laya.Event.CLICK, this, () => {
                com.isGameOver = false;
                StarCreate.instance.showGameUI(true);
            });
        }
        showUIName(isShow) {
            this.startPanel.visible = isShow;
        }
    }
    StartPanelCtr.instance = null;

    class GameConfig {
        constructor() { }
        static init() {
            var reg = Laya.ClassUtils.regClass;
            reg("script/GameUI.ts", GameUI);
            reg("script/StartPanelCtr.ts", StartPanelCtr);
            reg("script/StarCreate.ts", StarCreate);
            reg("script/OverCtr.ts", OverCtr);
        }
    }
    GameConfig.width = 750;
    GameConfig.height = 1334;
    GameConfig.scaleMode = "fixedwidth";
    GameConfig.screenMode = "none";
    GameConfig.alignV = "top";
    GameConfig.alignH = "left";
    GameConfig.startScene = "test/TestScene.scene";
    GameConfig.sceneRoot = "";
    GameConfig.debug = false;
    GameConfig.stat = false;
    GameConfig.physicsDebug = false;
    GameConfig.exportSceneToJson = true;
    GameConfig.init();

    class Main {
        constructor() {
            if (window["Laya3D"])
                Laya3D.init(GameConfig.width, GameConfig.height);
            else
                Laya.init(GameConfig.width, GameConfig.height, Laya["WebGL"]);
            Laya["Physics"] && Laya["Physics"].enable();
            Laya["DebugPanel"] && Laya["DebugPanel"].enable();
            Laya.stage.scaleMode = GameConfig.scaleMode;
            Laya.stage.screenMode = GameConfig.screenMode;
            Laya.stage.alignV = GameConfig.alignV;
            Laya.stage.alignH = GameConfig.alignH;
            Laya.URL.exportSceneToJson = GameConfig.exportSceneToJson;
            if (GameConfig.debug || Laya.Utils.getQueryString("debug") == "true")
                Laya.enableDebugPanel();
            if (GameConfig.physicsDebug && Laya["PhysicsDebugDraw"])
                Laya["PhysicsDebugDraw"].enable();
            if (GameConfig.stat)
                Laya.Stat.show();
            Laya.alertGlobalError(true);
            Laya.ResourceVersion.enable("version.json", Laya.Handler.create(this, this.onVersionLoaded), Laya.ResourceVersion.FILENAME_VERSION);
        }
        onVersionLoaded() {
            Laya.AtlasInfoManager.enable("fileconfig.json", Laya.Handler.create(this, this.onConfigLoaded));
        }
        onConfigLoaded() {
            GameConfig.startScene && Laya.Scene.open(GameConfig.startScene);
        }
    }
    new Main();

}());
