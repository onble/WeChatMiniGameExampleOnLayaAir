import com from "./Common";
import StarCreate from "./StarCreate";

export default class starControl extends Laya.Script {
    private star:Laya.Image;
    public index_x:number=0;
    public index_y:number=0;
    constructor() {
        super();
    }
    onAwake(){
        this.star=this.owner as Laya.Image;
        this.onClick();
    }
    
    public onClick() {
        // 
        this.star.on(Laya.Event.MOUSE_DOWN,this,this.clcikCallBack);
    }
    public offClick(){
        this.star.off(Laya.Event.MOUSE_DOWN,this,this.clcikCallBack)
    }
    private clcikCallBack(){
        if(com.isGameOver)return;
        console.log("1111");
        StarCreate.instance.clickStar(this.index_x,this.index_y);
    }
}