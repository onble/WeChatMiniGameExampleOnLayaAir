import com from "./Common";
import OverCtr from "./OverCtr";
import starControl from "./starControl";

/**
 * description
 * @ author:VKHOL
 * @ data: 2020-11-02 17:40
 */
export default class StarCreate extends Laya.Script {

    //单例
    public static instance: StarCreate = null;
    public startPos:Laya.Vector2=new Laya.Vector2(90,90);
    /**星星种类皮肤 */
    private starsSkin:Array<string>=["star/0.png","star/1.png","star/2.png","star/3.png","star/4.png"];
    /**星星之间的间隔 */
    private interval:number=75;
    /**当前界面 */
    private gamePanel:Laya.Image;
    /**星星父节点 */
    private stars:Laya.Image;
    /**创建星星数组 */
    private create_stars:Array<Laya.Image>=[];
    /**关卡数组 */
    private arr_maps:Array<Array<number>>=[];
    /**二维星星数组 */
    private arr_stars:Array<Array<Laya.Image>>=[];
    /**横排的星星数量 */
    private h_starnums:number=7;
    /**竖排的星星数量 */
    private v_starnums:number=11;
    /**得分Label */
    private score:Laya.Label;
    constructor() {
        super();
        StarCreate.instance = this;
    }

    onAwake(): void {
        this.gamePanel=this.owner as Laya.Image;
        this.stars=this.gamePanel.getChildByName("bg").getChildByName("stars") as Laya.Image;
        this.score=this.gamePanel.getChildByName("score") as Laya.Label;
    }

    onStart(): void {
        
    }
    private showGameScore(){
        this.score.text=""+com.score;
    }
    public showGameUI(isShow:boolean){
        this.gamePanel.visible=isShow;
        if(isShow){
            this.randMap();
            this.showGameScore();
        }
        else{
            this.clearStar();
        }
    }
    /**关卡重置 */
    clearStar(){
        for(let i=0;i<this.h_starnums;i++){
            for(let j=0;j<this.v_starnums;j++){
                if(this.arr_stars[i][j]!=null){
                    this.recoveryStar(this.arr_stars[i][j]);
                }
            }
        }
        this.arr_stars=[];
        this.arr_maps=[];
        com.isGameOver=false;
        com.score=0;
        this.showGameScore();
    }
    /**随机生成关卡数组 */
    randMap(){
        console.log("创建");
        for(let i=0;i<this.h_starnums;i++){
            let arr1:Array<Laya.Image>=[];
            let arr2:Array<number>=[];
            this.arr_stars.push(arr1);
            this.arr_maps.push(arr2);
            for(let j=0;j<this.v_starnums;j++){
                let rand:number=Math.floor(Math.random()*5)+1;
                let star:Laya.Image=null;
                this.arr_maps[i].push(rand);
                this.arr_stars[i].push(star);
            }
        }
        this.createMap();
    }
    /**生成星星 */
    createStar(num:number,pos:Laya.Vector2){
        let star:Laya.Image=null;
        if(this.create_stars.length>0){
            star=this.create_stars.pop();
        }
        else{
            star=new Laya.Image(this.starsSkin[num]);
            star.width=70;
            star.height=70;
            star.anchorX=0.5;
            star.anchorY=0.5;
            star.addComponent(starControl);
            // let starLabel=new Laya.Label();
            // starLabel.name="starLabel";
            // starLabel.fontSize=40;
            // star.addChild(starLabel);
        }
        this.stars.addChild(star);
        // star.getComponent(starControl).onClick();
        star.x=pos.x;
        star.y=pos.y;
        return star;
    }
    recoveryStar(obj:Laya.Image){
        if(obj.parent){
            // obj.getComponent(starControl).offClick();
            obj.destroy();
            // this.create_stars.push(obj);
        }
    }
    /**生成地图 */
    createMap(){
        for(let i=0;i<this.h_starnums;i++){
            for(let j=0;j<this.v_starnums;j++){
                if(this.arr_maps[i][j]!=0){
                    let star:Laya.Image=this.createStar(this.arr_maps[i][j]-1,new Laya.Vector2(this.startPos.x+this.interval*i,this.startPos.y+this.interval*j));
                    // (star.getChildByName("starLabel") as Laya.Label).text=i+"-"+j;
                    this.arr_stars[i][j]=star;
                    star.getComponent(starControl).index_x=i;
                    star.getComponent(starControl).index_y=j;
                }
            }
        }
        // console.log(this.arr_maps);
    }
    /**点击的星星 */
    clickStar(index_x:number,index_y:number){
        let arr=[];
        let V_arr=[];
        this.getIdenticalStar(index_x,index_y,arr);
        if(arr.length!=0){
            for(let i=0;i<arr.length;i++){
                this.recoveryStar(this.arr_stars[arr[i].x][arr[i].y]);
                this.arr_stars[arr[i].x][arr[i].y]=null;
                this.arr_maps[arr[i].x][arr[i].y]=0;
                if(!this.isInArr(V_arr,arr[i].x)){
                    V_arr.push(arr[i].x);
                }
            }
            for(let i=0;i<V_arr.length;i++){
                this.V_Sort(V_arr[i]);
            }
            for(let i=0;i<V_arr.length;i++){
                this.H_Sort(V_arr[i]);
            }
            if(this.IsOver()){
                console.log("游戏结束");
                com.isGameOver=true;
                OverCtr.instance.showUIName(true);
            }
            if(arr.length<=2){
                com.score+=10*arr.length;
                
            }
            else if(arr.length<=4){
                com.score+=20*arr.length;
            }
            else{
                com.score+=35*arr.length;
            }
            this.showGameScore();
        };
    }
    /**竖排排序 */
    private V_Sort(num){
        let down:number=0;
        for(let i=this.v_starnums-1;i>=0;i--){
            let ishave:boolean=false;
            if(this.arr_maps[num][i]==0){
                for(let j=i-1;j>=0;j--){
                    if(this.arr_maps[num][j]!=0){
                        ishave=true;
                        this.arr_stars[num][j].getComponent(starControl).index_y+=1;
                        Laya.Tween.to(this.arr_stars[num][j],{y:this.startPos.y+this.interval*this.arr_stars[num][j].getComponent(starControl).index_y},100,null);
                    }
                }
                if(ishave){
                    down++;
                }
            }
        }
        if(down!=0){
            for(let i=this.v_starnums-1;i>=0;i--){
                if(this.arr_maps[num][i]!=0){
                    let starnum:number=this.arr_maps[num][i];
                    this.arr_maps[num][i]=0;
                    let star=this.arr_stars[num][i];
                    this.arr_stars[num][i]=null;
                    let control:starControl=star.getComponent(starControl);
                    this.arr_maps[control.index_x][control.index_y]=starnum;
                    this.arr_stars[control.index_x][control.index_y]=star;
                    // (star.getChildByName("starLabel") as Laya.Label).text=control.index_x+"-"+control.index_y;
                }
            }
        }
    }
    /**横排排序 */
    private H_Sort(num){
        if(this.isV_Star(num)){
            return;
        }
        else{
            let isMove:boolean=false;
            for(let i=num;i<this.h_starnums;i++){
                for(let j=0;j<this.v_starnums;j++){
                    if(this.arr_stars[i][j]!=null){
                        let star=this.arr_stars[i][j];
                        let control:starControl=star.getComponent(starControl);
                        control.index_x-=1;
                        // star.x=this.startPos.x+80*control.index_x;
                        Laya.Tween.to(star,{x:this.startPos.x+this.interval*control.index_x},100,null);
                        isMove=true;
                    }
                }
            }
            if(isMove){
                for(let i=num;i<this.h_starnums;i++){
                    for(let j=0;j<this.v_starnums;j++){
                        if(this.arr_stars[i][j]!=null){
                            let star=this.arr_stars[i][j];
                            let starnum:number=this.arr_maps[i][j];
                            this.arr_stars[i][j]=null;
                            this.arr_maps[i][j]=0;
                            let control:starControl=star.getComponent(starControl);
                            this.arr_maps[control.index_x][control.index_y]=starnum;
                            this.arr_stars[control.index_x][control.index_y]=star;
                        }
                    }
                }
            }
        }
    }
    /**获取周围相同品类的星星 四方向判断 */
    getIdenticalStar(index_x:number,index_y:number,arr){
        let starnum:number=this.arr_maps[index_x][index_y];
        for(let i=-1;i<=1;i++){
            for(let j=-1;j<=1;j++){
                if(Math.abs(i+j)==1){
                    if(this.isLimit(index_x+i,index_y+j)){
                        if(this.arr_maps[index_x+i][index_y+j]==starnum){
                            if(this.isInAarry(arr,{x:index_x+i,y:index_y+j})==false){
                                arr.push({x:index_x+i,y:index_y+j});
                                this.getIdenticalStar(index_x+i,index_y+j,arr);
                            }
                        }
                    }
                }
            }
        }
    }
    /**判断竖排是否有星星 */
    private isV_Star(num){
        let ishaveStar:boolean=false;
        for(let i=0;i<this.v_starnums;i++){
            if(this.arr_stars[num][i]!=null){
                ishaveStar=true;
            }
        }
        return ishaveStar;
    }
    /**判断周围是否有相同星星 */
    IsSameStar(index_x:number,index_y:number):boolean{
        let starnum:number=this.arr_maps[index_x][index_y];
        let ishave:boolean=false;
        for(let i=-1;i<=1;i++){
            for(let j=-1;j<=1;j++){
                if(Math.abs(i+j)==1){
                    if(this.isLimit(index_x+i,index_y+j)){
                        if(this.arr_maps[index_x+i][index_y+j]==starnum){
                            ishave=true;
                            break;
                        }
                    }
                }
            }
            if(ishave==true){
                break;
            }
        }
        return ishave;
    }
    /**是否在边界内 */
    private isLimit(index_x:number,index_y:number):boolean{
        if(index_x>=0&&index_x<this.h_starnums&&index_y>=0&&index_y<this.v_starnums){
            return true;
        }
        else{
            return false;
            
        }
    }
    /**是否在数组里 */
    private isInAarry(arr,obj){
        let isIn:boolean=false;
        for(let i=0;i<arr.length;i++){
            if(arr[i].x==obj.x&&arr[i].y==obj.y){
                isIn=true;
                break;
            }
        }
        return isIn;
    }
    /**该元素是否在数组中 */
    private isInArr(arr,num:number){
        let isIn:boolean=false;
        for(let i=0;i<arr.length;i++){
            if(arr[i]==num){
                isIn=true;
                break;
            }
        }
        return isIn;
    }
    /**判断游戏是否结束 */
    private IsOver(){
        let isover:boolean=true;
        for(let i=0;i<this.h_starnums;i++){
            for(let j=this.v_starnums-1;j>=0;j--){
                if(this.arr_maps[i][j]!=0){
                    if(this.IsSameStar(i,j)==true){
                        isover=false;
                        break;
                    }
                }
            }
            if(!isover){
                break;
            }
        }
        return isover;
    }
    /**是否跟本 */
}