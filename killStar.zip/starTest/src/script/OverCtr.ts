
import StarCreate from "./StarCreate";
import StartPanelCtr from "./StartPanelCtr";
import com from "./Common";

/**
 * description
 * @ author:VKHOL
 * @ data: 2020-11-03 18:09
 */
export default class OverCtr extends Laya.Script {

    //单例
    public static instance: OverCtr = null;
    private overPanel:Laya.Image;
    private back_bt:Laya.Image;
    private score:Laya.Label;

    constructor() {
        super();
        OverCtr.instance = this;
    }

    onAwake(): void {
        this.overPanel=this.owner as Laya.Image;
        this.back_bt=this.overPanel.getChildByName("back_bt") as Laya.Image;
        this.score=this.overPanel.getChildByName("score") as Laya.Label;
    }

    onStart(): void {
        this.back_bt.on(Laya.Event.CLICK,this,()=>{
            this.showUIName(false);
            StartPanelCtr.instance.showUIName(true);
        })
    }

    /**
     * 显示/隐藏 **界面
     * @param isShow 显示/隐藏
     */
    public showUIName(isShow: boolean): void {
        this.overPanel.visible=isShow;
        if(isShow){
            this.score.text=""+com.score;
            StarCreate.instance.showGameUI(false);
        }
    }
}