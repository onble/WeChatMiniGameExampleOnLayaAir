import com from "./Common";
import StarCreate from "./StarCreate";

/**
 * description
 * @ author:VKHOL
 * @ data: 2020-11-03 17:41
 */
export default class StartPanelCtr extends Laya.Script {

    //单例
    public static instance: StartPanelCtr = null;
    private startPanel:Laya.Image;
    private start_bt:Laya.Image;

    constructor() {
        super();
        StartPanelCtr.instance = this;
    }

    onAwake(): void {
        this.startPanel=this.owner as Laya.Image;
        this.start_bt=this.startPanel.getChildByName("start_bt") as Laya.Image;
    }

    onStart(): void {
        this.start_bt.on(Laya.Event.CLICK,this,()=>{
            com.isGameOver=false;
            StarCreate.instance.showGameUI(true);
        })
    }

    /**
     * 显示/隐藏 **界面
     * @param isShow 显示/隐藏
     */
    public showUIName(isShow: boolean): void {
        this.startPanel.visible=isShow;
    }
}