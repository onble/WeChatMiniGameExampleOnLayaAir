let com={
    isGameOver:false,
    score:0,
}
export default com;