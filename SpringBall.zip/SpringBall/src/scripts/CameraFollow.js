/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-10 09:22
*/
export default class CameraFollow extends Laya.Script {

    constructor() {
        super();
        /** @prop {name:name, tips:"提示文本", type:Node, default:null}*/
        this.xx=null;
    }

    onAwake() {
        Laya.stage.on("MoveCamera",this,this.follow);
        Laya.stage.on("Continue",this,function(){
            this.owner.transform.localPositionY=1.3;
        })
    }
    follow(posY){
        Laya.Tween.to(this.owner.transform,{localPositionY:posY},300);
    }
}