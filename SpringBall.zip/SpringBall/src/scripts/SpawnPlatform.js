/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-09 15:35
*/
export default class SpawnPlatform extends Laya.Script {

    constructor() {
        super();
        this.initPosY=-1;
        this.spawnCount=0;

        //存放所有生成的平台
        this.platformArr=[];
    }
    init(prefab,parent){
        this.prefab=prefab;
        this.parent=parent;

        for(var i=0;i<5;i++){
            this.spawn();
        }

        Laya.stage.on("CreatPlatform",this,this.spawn);
        Laya.stage.on("Continue",this,function(){
            //首先把场景中存在的平台销毁掉
            this.platformArr.forEach(element => {
                if(element.displayedInStage){
                    element.removeSelf();
                    //element.destroy();
                    Laya.Pool.recover("Platform",element);
                }
            });

            //重新生成5个平台
            this.spawnCount=0;
            for(var i=0;i<5;i++){
                this.spawn();
            }
        })
    }
    //生成平台
    spawn(){
        //从对象池中取对象
        var temp=Laya.Pool.getItemByCreateFun("Platform",this.creatFun,this);
        this.parent.addChild(temp);
        temp.transform.localPosition=new Laya.Vector3(0,this.initPosY-(1.5*this.spawnCount),0);
        this.setPlatform(temp)
        this.platformArr.push(temp);

        this.spawnCount++;
    }
    //如果对象池没有能取出来的对象，则使用这个方法进行创建
    creatFun(){
        var temp=Laya.Sprite3D.instantiate(this.prefab,this.parent);
        return temp;
    }
    //设置平台的随机空位置与障碍位置
    setPlatform(platform){
        //第一个生成的平台需要我们特殊设置，防止第一个就掉下去或者over
        if(this.spawnCount==0){
            for(var i=0;i<platform.numChildren;i++){
                var bar=platform.getChildAt(i);
                bar.meshRenderer.material._ColorR=0;
                bar.meshRenderer.material._ColorG=0;
                bar.meshRenderer.material._ColorB=0;
                bar.name="Bar";
                
                if(i==0||i==1){
                    bar.meshRenderer.enable=false;
                    bar.getComponent(Laya.PhysicsCollider).isTrigger=true;
                }else{
                    bar.meshRenderer.enable=true;
                    bar.getComponent(Laya.PhysicsCollider).isTrigger=false;
                }
            }
            return;
        }

        var nullCount=0;
        var obstacleValue=this.getRandom(0,platform.numChildren-1);
        
        for(var i=0;i<platform.numChildren;i++){
            var bar=platform.getChildAt(i);
            //还原所有Bar为初始状态
            bar.meshRenderer.enable=true;
            bar.getComponent(Laya.PhysicsCollider).isTrigger=false;
            bar.meshRenderer.material._ColorR=0;
            bar.meshRenderer.material._ColorG=0;
            bar.meshRenderer.material._ColorB=0;
            bar.name="Bar";

            //控制一下空位置的数量，不能超过4个
            if(obstacleValue!=i&&nullCount<=4&&this.getRandom(0,10)>8){
               nullCount++;
               bar.meshRenderer.enable=false;
               bar.getComponent(Laya.PhysicsCollider).isTrigger=true;
            }
            else if(obstacleValue==i){
                bar.name="Obstacle";
                bar.meshRenderer.material._ColorR=1;
                bar.meshRenderer.material._ColorG=0;
                bar.meshRenderer.material._ColorB=0;
            }
        }
        //一个空位置也没有产生的情况
        if(nullCount==0){
            var bar=platform.getChildAt(0);
            bar.name="Bar";
            bar.meshRenderer.enable=false;
            bar.getComponent(Laya.PhysicsCollider).isTrigger=true;
        }
    }
    //随机min~max之间的随机数
    getRandom(min,max){
        var delta=max-min;
        var ranValue=Math.random()*delta;
        ranValue=Math.round(ranValue);
        return min+ranValue;
    }
}