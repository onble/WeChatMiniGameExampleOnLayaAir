/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-09 13:14
*/
export default class Rotation extends Laya.Script {

    constructor() {
        super();
        this.lastMouseX=0;
        //是否是第一次触摸
        this.firstTouch=true;
        //游戏是否结束
        this.gameOver=false;
    }
    init(scene){
        this.scene=scene;
    }
    onAwake() {
        Laya.stage.on("GameOver",this,function(){this.gameOver=true})
        Laya.stage.on("Continue",this,function(){
            this.gameOver=false
            this.owner.transform.localRotationEulerY=0;
        })

        if(Laya.Browser.onPC){
            //监听鼠标按下、抬起、移除舞台的事件
            Laya.stage.on(Laya.Event.MOUSE_DOWN,this,this.mouseDown)
            Laya.stage.on(Laya.Event.MOUSE_UP,this,function(){
                Laya.stage.off(Laya.Event.MOUSE_MOVE,this,this.mouseMove)
            })
            Laya.stage.on(Laya.Event.MOUSE_OUT,this,function(){
                Laya.stage.off(Laya.Event.MOUSE_MOVE,this,this.mouseMove)
            })
        }
    }
    //鼠标按下
    mouseDown(){
        if(this.gameOver)return;

        this.lastMouseX=Laya.stage.mouseX;
        //Laya.MouseManager.instance.mouseY
        Laya.stage.on(Laya.Event.MOUSE_MOVE,this,this.mouseMove)
    }
    //鼠标按下并且移动会触发这个方法
    mouseMove(){
        if(this.gameOver)return;
        var deltaX=Laya.stage.mouseX-this.lastMouseX;
        this.lastMouseX=Laya.stage.mouseX;
        this.owner.transform.rotate(new Laya.Vector3(0,deltaX/5,0),true,false);
    }
    onUpdate(){
        if(this.gameOver)return;
        if(Laya.Browser.onMobile==false)return;
        
        //获取触摸手指数量
        if(this.scene.input.touchCount()==1){
            var touch=this.scene.input.getTouch(0);
            if(this.firstTouch){
                this.firstTouch=false;
                this.lastMouseX=touch.position.x;
            }else{
                var deltaX=touch.position.x-this.lastMouseX;
                this.lastMouseX=touch.position.x;
                this.owner.transform.rotate(new Laya.Vector3(0,deltaX/2,0),true,false);
            }
        }else{
            this.firstTouch=true;
            this.lastMouseX=0;
        }
    }
}