import ScoreHint from "./ScoreHint";

/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-09 14:59
*/
export default class PlayerCtrl extends Laya.Script3D {

    constructor() {
        super();
        this.controller=null;
        this.ThroughCount=0;
    }

    onAwake() {
        //获取场景的物理模拟器，用于发射射线
        this.physicsSimulation=this.owner.parent.physicsSimulation;
        //创建射线
        this.ray=new Laya.Ray(new Laya.Vector3(),new Laya.Vector3(0,-1,0));
        //射线检测的返回
        this.hitResult=new Laya.HitResult();

        this.controller=this.owner.addComponent(Laya.CharacterController);
        
        var col=new Laya.SphereColliderShape(0.5);
        this.controller.colliderShape=col;
        this.controller.fallSpeed=10;
        this.controller.jumpSpeed=7;

        Laya.timer.frameLoop(1,this,this.RayCast);

        this.scoreHint=ScoreHint.getInstance();

        Laya.stage.on("Continue",this,function(){
            this.owner.transform.localScaleY=0.3;
            this.owner.transform.localPositionY=0;
        })
    }
    RayCast(){
        this.ray.origin=this.owner.transform.position;
        
        if(this.ThroughCount>=3&&this.physicsSimulation.rayCast(this.ray,this.hitResult,0.2)){
            var col=this.hitResult.collider;
            var numChildren=col.owner.parent.numChildren;
            for(var i=0;i<numChildren;i++){
                var bar=col.owner.parent.getChildAt(i);
                bar.name="Bar";
                bar.meshRenderer.material._ColorR=0;
                bar.meshRenderer.material._ColorG=0;
                bar.meshRenderer.material._ColorB=1;
            }
        }
        if(this.physicsSimulation.rayCast(this.ray,this.hitResult,0.15)){
            var col=this.hitResult.collider;

            //游戏结束
            if(col.owner.name=="Obstacle"){
                this.owner.transform.localScaleY=0.15;
                Laya.stage.event("GameOver");
                return;
            }
            if(col.isTrigger){
                this.ThroughCount++;
                
                col.owner.parent.removeSelf();
                //回收
                Laya.Pool.recover("Platform",col.owner.parent);

                //摄像机跟随
                Laya.stage.event("MoveCamera",[col.owner.parent.transform.localPositionY]);
                //生成新的平台
                Laya.stage.event("CreatPlatform");
                //移动柱子
                Laya.stage.event("MoveColumn");
                //成绩增加
                this.scoreHint.showHint(1);
                Laya.stage.event("AddScore",1)

                Laya.SoundManager.playSound("sound/DestSound.mp3",1);
            }else{
                if(this.ThroughCount>=3){
                    //成绩增加
                    this.scoreHint.showHint(this.ThroughCount);
                    Laya.stage.event("AddScore",this.ThroughCount)
                }
                this.ThroughCount=0;
                this.controller.jump();
                Laya.stage.event("CreatParticle",this.hitResult.point);
                Laya.SoundManager.playSound("sound/jumpSound.mp3",1);
            }
        }
    }
}