/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-10 15:35
*/
export default class UIManager extends Laya.Script {

    constructor() {
        super();
        /** @prop {name:txt_Score, tips:"提示文本", type:Node, default:null}*/
        this.txt_Score=null;
        /** @prop {name:gameOverPanel, tips:"提示文本", type:Node, default:null}*/
        this.gameOverPanel=null;

        this.score=0;
        this.mute=false;
    }

    onAwake() {
        this.gameOverPanel.visible=false;
        Laya.stage.on("AddScore",this,this.addScore);
        Laya.stage.on("GameOver",this,function(){
            this.gameOverPanel.visible=true;
            this.txt_Score.visible=false;
            this.gameOverPanel.getChildByName("txt_Score").text=this.score;
        })
        this.gameOverPanel.getChildByName("btn_Continue").on(Laya.Event.CLICK,this,function(){
            Laya.stage.event("Continue");
            this.gameOverPanel.visible=false;
            this.txt_Score.visible=true;
            this.score=0;
            this.txt_Score.text=this.score;
        })
        this.gameOverPanel.getChildByName("btn_Mute").on(Laya.Event.CLICK,this,function(){
            this.mute=!this.mute;
            Laya.SoundManager.soundMuted=this.mute
            if(this.mute){
                this.gameOverPanel.getChildByName("btn_Mute").label="开启音效"
            }else{
                this.gameOverPanel.getChildByName("btn_Mute").label="关闭音效"
            }
        })
    }
    //成绩增加
    addScore(value){
        this.score+=value;
        this.txt_Score.text=this.score;
    }
}