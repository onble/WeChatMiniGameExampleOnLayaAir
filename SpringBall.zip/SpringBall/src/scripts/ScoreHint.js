/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-10 14:52
*/
export default class ScoreHint extends Laya.Script {

    constructor() {
        super();
        // /** @prop {name:txt_Hint, tips:"提示文本", type:Prefab, default:null}*/
        // this.txt_Hint=null;
        this.txt_Hint=null;
        this.instance=null;

        Laya.loader.load("prefab/txt_Hint.json",Laya.Handler.create(this,
            function(prefab){
                this.txt_Hint=prefab;
            }),null,Laya.Loader.PREFAB);
    }
    static getInstance(){
        return this.instance==null?this.instance=new ScoreHint():this.instance;
    }
    //显示提示信息，实例化提示文本预制体
    showHint(score){
        var hint=Laya.Pool.getItemByCreateFun("Txt_Hint",this.creatFun,this);
        Laya.stage.addChild(hint);
        // hint.x=192;
        // hint.y=860.5;
        hint.pos(192,860.5);
        hint.text="+"+score;
        Laya.Tween.to(hint,{y:860.5-100},500,Laya.Ease.backIn,Laya.Handler.create(
            this,function(){
                //回收到对象池
                hint.removeSelf();
                Laya.Pool.recover("Txt_Hint",hint);
            }
        ),100)
    }
    creatFun(){
        var temp=this.txt_Hint.create();
        return temp;
    }
}