import Rotation from "./Rotation";
import PlayerCtrl from "./PlayerCtrl";
import SpawnPlatform from "./SpawnPlatform";
import CameraFollow from "./CameraFollow";

/**
*
* @ author:Carson
* @ email:976627526@qq.com
* @ data: 2020-01-09 11:33
*/
export default class GameEnter extends Laya.Script {

    constructor() {
        super();
    }

    onAwake() {
        Laya.Scene3D.load("res/scene/LayaScene_Main/Conventional/Main.ls",Laya.Handler.create(this,this.loadFinished));
        Laya.stage.on("MoveColumn",this,this.moveColumn);
        Laya.stage.on("CreatParticle",this,this.spawnParticle);
        Laya.stage.on("Continue",this,function(){
            this.column.transform.localPositionY=0;
        })
    }
    loadFinished(scene){
        this.scene=scene;
        scene.zOrder=-1;

        Laya.stage.addChild(scene);
        scene.getChildByName("Parent").addComponent(Rotation).init(scene);
        var player=scene.getChildByName("Player");
        player.addComponent(PlayerCtrl);
        var trail=scene.getChildByName("TrailRender");
        player.addChild(trail);
        trail.transform.localPosition=new Laya.Vector3();

        var parent=scene.getChildByName("Parent");
        this.column=parent.getChildByName("Column");

        var platform=parent.getChildByName("Platform");
        var platformPre=Laya.Sprite3D.instantiate(platform);
        platform.active=false;
        this.owner.addComponent(SpawnPlatform).init(platformPre,parent);

        scene.getChildByName("Main Camera").addComponent(CameraFollow);

        //粒子特效
        var particle=scene.getChildByName("Prticle");
        this.particlePre=Laya.Sprite3D.instantiate(particle);
        particle.active=false;
    }
    //柱子的移动
    moveColumn(){
        this.column.transform.localPositionY-=1.5;
    }
    spawnParticle(pos){
        var particle=Laya.Pool.getItemByCreateFun("Particle",this.creatFun,this);
        this.scene.addChild(particle);
        particle.transform.position=pos;
        Laya.timer.once(1500,this,function(){
            particle.removeSelf();
            Laya.Pool.recover("Particle",particle);
        })
    }
    creatFun(){
        var temp=Laya.Sprite3D.instantiate(this.particlePre,this.scene);
        return temp;
    }
}